/*=============================================================================
|   Source code: BRectTester.java
|        Author: Yonal Hernandez
|    Student ID: 6178656
|    Assignment: Program #4 Better Rectangle
|
|        Course: COP3337 Computer Programing II
|       Section: U02
|    Instructor: William Feild
|      Due Date: March 7, 2019 at the beginning of class
|
|	I hereby certify that this collective work is my own
|	and none of it is the work of any other person or entity.
|	_______Yonal Hernandez__________________________________
|
|      Language: Java
|   Compile/Run: Compile and run
| 	       javac BRectTester.java  BetterRectangle.java
|	       java  BRectTester
|
|  +-----------------------------------------------------------------------------
|
|  Description: Program provides a BetterRectangle sub-class that extends the
|               java.awt.Rectangle class of the standard Java library by adding
|               methods to compute the area, perimeter, slope and mid-point of the
|               rectangle, as well as valid constructors for the new sub-class.
|               Provides a BRectTester program that will execute and validate the
|               BetterRectangle sub-class.
|
|        Input: No user input required. Rectangles are “hard-coded”.
|
|       Output: Provide validation that all new features in the sub-class are
|               functioning properly - presented in a clearly labeled, readable
|               and attractive manner. Display “before” and “after” to feature
|               the mutator method and expected values for the utility methods.
|
|      Process:
|               1. Hard-code rectangles.
|               2. Display Rectangles.
|               3. Display Accessor Methods.
|               4. Display Utility Methods next to expected values.
|               5. Display Mutator Method.
|
|   Required Features Not Included:  None.
|
|   Known Bugs: None
|  *===========================================================================*/

public class BRectTester
{

    public static void main(String[] args)
    {
        BetterRectangle bRectA = new BetterRectangle(3,4);
        BetterRectangle bRectB = new BetterRectangle(bRectA);
        BetterRectangle bRectC = new BetterRectangle(1,1,4,3);
        BetterRectangle bRectD = new BetterRectangle();

        displayRectangles(bRectA, bRectB, bRectC, bRectD);
        displayAccessorMethods(bRectA);
        displayUtilityMethods(bRectB, bRectC);
        displayMutatorMethod(bRectD);

    }

    /*---------------------- displayMutatorMethod ----------------------------
         |  Method displayMutatorMethod(BetterRectangle bRectD)
         |
         |Purpose: Display the before and after of the mutator method scaleBy.
         |         Use an int (scale) as parameter
         |         Value of scale is pre-fixed to 4 and -4.
         |
         |  @param bRectD
         |
         | @return None
         *-------------------------------------------------------------------*/
    private static void displayMutatorMethod(BetterRectangle bRectD)
    {
        int scale = 4;
        System.out.println("\nMutator methods being executed for Rectangle D...");
        System.out.printf("D: %s %n", bRectD.toString());
        System.out.printf("%2s %s %2s? %-5s %n","", "Scale by: ", scale,
                bRectD.setScaleBy(scale));
        System.out.printf("D: %s %n", bRectD.toString());
        scale = -4;
        System.out.printf("%2s %s %2s? %-5s %n","", "Scale by: ", scale,
                bRectD.setScaleBy(scale));
    }

    /*---------------------- displayUtilityMethods ----------------------------
         |  Method displayUtilityMethods(BetterRectangle bRectB,
         |                               BetterRectangle bRectC)
         |
         |Purpose: Display the output of the utility methods. These methods,
         |         compare to bRectB and bRectC rectangles in different new
         |         aspects.
         |
         |  @param bRectB
         |  @param bRectC
         |
         | @return None
         *-------------------------------------------------------------------*/
    private static void displayUtilityMethods(BetterRectangle bRectB,
                                              BetterRectangle bRectC)
    {
        System.out.println("\nUtility methods being executed for Rectangle B " +
                "and C...");
        System.out.printf("B: %s %n", bRectB.toString());
        System.out.printf("C: %s %n", bRectC.toString());
        System.out.printf("%2s %-14s %-10s %s %n","", "Equals? ",
                bRectB.equals(bRectC), "Expected: false");
        System.out.printf("%2s %-14s %-10s %s %n","", "Proportional? ",
                bRectB.isProportional(bRectC), "Expected: false");
        System.out.printf("%2s %-14s %-10s %s %n","", "Equivalent? ",
                bRectB.isEquivalent(bRectC), "Expected: true");
        System.out.printf("%2s %-14s %-10s %s %n","", "Similar? ",
                bRectB.isSimilar(bRectC), "Expected: true");
        System.out.printf("%2s %-14s %-10s %s %n","", "Concentric? ",
                bRectB.isConcentric(bRectC), "Expected: false");
    }

    /*---------------------- displayAccessorMethods ----------------------------
         |  Method displayAccessorMethods(BetterRectangle bRectA)
         |
         |Purpose: Display the output of the accessor methods. These methods,
         |         compute the area, perimeter, slope and mid-point of a
         |         given rectangle. Slope is displayed with 2 decimal places
         |         using String.format() method and TWO_DECIMAL_PLACES_FORMAT
         |         constant from the BetterRectangle class is passed as parameter.
         |         It was decided that way to be easily changed in the future.
         |         Refer to Big Java: Early Objects, 5th Edition page A-27
         |
         |  @param bRectA
         |
         | @return None
         *-------------------------------------------------------------------*/
    private static void displayAccessorMethods(BetterRectangle bRectA)
    {
        System.out.println("\nAccessor methods being executed for Rectangle A...");
        System.out.printf("A: %s %n", bRectA.toString());
        System.out.printf("%2s %-14s %d %n","", "Area: ", bRectA.getArea());
        System.out.printf("%2s %-14s %d %n","", "Perimeter: ", bRectA.getPerimeter());
        System.out.printf("%2s %-14s %s %n","", "Slope: ",
                String.format(BetterRectangle.TWO_DECIMAL_PLACES_FORMAT, bRectA.getSlope()));
        System.out.printf("%2s %-14s (%.0f,%.0f) %n","", "MidPoint: ",
                bRectA.getMidPoint().getX(), bRectA.getMidPoint().getY());
    }

    /*---------------------- displayRectangles ----------------------------
         |  Method displayRectangles(BetterRectangle bRectA, BetterRectangle bRectB,
         |                      BetterRectangle bRectC, BetterRectangle bRectD)
         |
         |Purpose: Display the output of the toString method of the
         |         BetterRectangle subclass.
         |
         |  @param bRectA
         |  @param bRectB
         |  @param bRectC
         |  @param bRectD
         |
         | @return None
         *-------------------------------------------------------------------*/
    private static void displayRectangles(BetterRectangle bRectA,
                                          BetterRectangle bRectB,
                                          BetterRectangle bRectC,
                                          BetterRectangle bRectD)
    {
        System.out.printf("\nA: %s %n", bRectA.toString());
        System.out.printf("B: %s %n", bRectB.toString());
        System.out.printf("C: %s %n", bRectC.toString());
        System.out.printf("D: %s %n", bRectD.toString());

    }
}
