/*=======================================================================
|     Source code: BetterRectangle.java
|           Class: BetterRectangle
|          Author: Yonal Hernandez
|      Student ID: 6178656
|      Assignment: Program #4 Better Rectangle
|
|          Course: COP3337 Computer Programing II
|         Section: U02
|      Instructor: William Feild
|        Due Date: March 7, 2019 at the beginning of class
|
|	I hereby certify that this collective work is my own
|	and none of it is the work of any other person or entity.
|	_______Yonal Hernandez__________________________________
|
|        Language: Java
|     Compile/Run: Compile
| 	         javac BetterRectangle.java
|
|         Purpose: Inherits from the java.awt.Rectangle class of the API.
|                  Add some accessors, mutator and utility methods
|                  in order to create a more complete Rectangle
|                  class. Also override the method equals and
|                  to string, including new characteristics.
|                  For more information about the methods used from the
|                  java.awt.Rectangle class, please refer to:
|          https://docs.oracle.com/javase/7/docs/api/java/awt/Rectangle.html
|                  or Big Java: Early Objects, 5th Edition page A-15
|
|                  Use the following classes:
|                   java.awt.Point : create points based on two coordinates
|                   java.lang.Math : use methods from the Math class.
|
|   Inherits From: java.awt.Rectangle
|
|      Interfaces: None
|
|  +-----------------------------------------------------------------------
|
|       Constants:
|
|    public static final int ORIGIN = 0;
|       Origin of coordinates.
|
|    public static final int UNIT = 1;
|       Unit rectangles.
|
|    public static final String TWO_DECIMAL_PLACES_FORMAT = "%.2f";
|       Decimal places required for the slope to be used in the
|       String.format() as a parameter.
|
|    public static final int NO_VALUE = 0;
|       Fixed value to avoid magic numbers.
|
|    private static final double THRESHOLD_CONDITION = 0.001;
|       Fixed value to compare floating point numbers.
|
| +-----------------------------------------------------------------------
|
|    Constructors:
|
|      BetterRectangle()
|           Creates a unit rectangle, anchored at Origin.
|		    [unit rectangle means height = width = 1].
|
|      BetterRectangle(int width, int height)
|           Creates rectangle, anchored at Origin
|
|      BetterRectangle(int x, int y, int width, int height)
|           Creates a rectangle.
|
|      BetterRectangle(BetterRectangle rectangle)
|           Creates a copy of rectangle.
|
|   Class Methods: None.
|
|Instance Methods:
|
|       public int getArea() :
|           return area;
|
|       public int getPerimeter() :
|           return perimeter;
|
|       public double getSlope() :
|           return slope;
|
|       public Point getMidPoint() :
|           return midPoint;
|
|       public boolean equals(Object rectangle) :
|           return equals;
|
|       public boolean isProportional(BetterRectangle rectangle) :
|           return proportional;
|
|       public boolean isEquivalent(BetterRectangle rectangle) :
|           return equivalent;
|
|       public boolean isSimilar(BetterRectangle rectangle) :
|           return similar;
|
|       public boolean isConcentric(BetterRectangle rectangle) :
|           return concentric;
|
|       public boolean setScaleBy(int scale) :
|           return scaleBy;
|
|       public String toString() :
|           return toString;
|
|  *===========================================================================*/

import java.awt.Point;//Allows the use of the Point Class.
import java.lang.Math;//Allows the use of the Math Class.

public class BetterRectangle extends java.awt.Rectangle
{
    public static final int ORIGIN = 0;
    public static final int UNIT = 1;
    public static final String TWO_DECIMAL_PLACES_FORMAT = "%.2f";
    public static final int NO_VALUE = 0;
    private static final double THRESHOLD_CONDITION = 0.001;


    /*---------------------------- BetterRectangle ----------------------------
         |  Method BetterRectangle()
         |
         |Purpose: Default constructor for BetterRectangle class.
         |         creates a unit rectangle, anchored at Origin.
         |         [unit rectangle means height = width = 1].
         |
         |  @param None
         |
         | @return None
         *-------------------------------------------------------------------*/
    public BetterRectangle()
    {
        setLocation(ORIGIN, ORIGIN);
        setSize(UNIT, UNIT);
    }

    /*---------------------------- BetterRectangle ----------------------------
         |  Method BetterRectangle(int width, int height)
         |
         |Purpose: Creates a rectangle, anchored at Origin.
         |
         |  @param width
         |  @param height
         |
         | @return None
         *-------------------------------------------------------------------*/
    public BetterRectangle(int width, int height)
    {
        setLocation(ORIGIN, ORIGIN);
        setSize(width, height);
    }

    /*---------------------------- BetterRectangle ----------------------------
         |  Method BetterRectangle(int x, int y, int width, int height)
         |
         |Purpose: Creates a rectangle.
         |
         |  @param x
         |  @param y
         |  @param width
         |  @param height
         |
         | @return None
         *-------------------------------------------------------------------*/
    public BetterRectangle(int x, int y, int width, int height)
    {
        setLocation(x,y);
        setSize(width, height);
    }

    /*---------------------------- BetterRectangle ----------------------------
         |  Method BetterRectangle(BetterRectangle rectangle)
         |
         |Purpose: Creates a copy of rectangle.
         |         Result is cast to Integer because getWidth(), getX(), getY()
         |         and getHeight() methods return a floating point value.
         |
         |  @param rectangle
         |
         | @return None
         *-------------------------------------------------------------------*/
    public BetterRectangle(BetterRectangle rectangle)
    {
        setLocation((int)rectangle.getX(), (int)rectangle.getY());
        setSize((int)rectangle.getWidth(), (int)rectangle.getHeight());
    }

    /*---------------------------- getArea ----------------------------
         |  Method getArea()
         |
         |Purpose: Compute the area for a desired rectangle.
         |         First it makes sure width and height are different than 0
         |         using isEmpty() method from it superclass. Method returns
         |         true if the rectangle has no values, false otherwise.
         |         Refer to:
         |  https://docs.oracle.com/javase/7/docs/api/java/awt/Rectangle.html
         |         Result is cast to Integer because getWidth() and
         |         getHeight() methods return a floating point value.
         |
         |          area = width * height
         |
         |  @param None
         |
         | @return area
         *-------------------------------------------------------------------*/
    public int getArea()
    {
        int area = NO_VALUE;
        if (!isEmpty())
        {
            area = (int)(getWidth() * getHeight());
        }
        else;
        return area;
    }

    /*---------------------------- getPerimeter ----------------------------
         |  Method getPerimeter()
         |
         |Purpose: Compute the perimeter for a desired rectangle. Perimeter
         |         is computed adding up the length of the 4 sides.
         |         First it makes sure width and height are different than 0
         |         using isEmpty() method from it superclass. Method returns
         |         true if the rectangle has no values, false otherwise.
         |         Refer to:
         |  https://docs.oracle.com/javase/7/docs/api/java/awt/Rectangle.html
         |         Result is cast to Integer because getWidth() and
         |         getHeight() methods return a floating point value.
         |
         |          perimeter = height + height + width + width
         |                    = 2 * (width + height)
         |                    = (int)(2 * (getWidth() + getHeight()))
         |
         |  @param None
         |
         | @return perimeter
         *-------------------------------------------------------------------*/
    public int getPerimeter()
    {
        int perimeter = NO_VALUE;
        if (!isEmpty())
        {
            perimeter = (int)(2 * (getWidth() + getHeight()));
        }
        else;
        return perimeter;
    }

    /*---------------------------- getSlope ----------------------------
         |  Method getSlope()
         |
         |Purpose: Compute the slope for a desired rectangle. The result is a
         |         floating point number that will be displayed with 2 decimal
         |         places accuracy.
         |         First it makes sure width and height are different than 0
         |         using isEmpty() method from it superclass. Method returns
         |         true if the rectangle has no values, false otherwise.
         |         Refer to:
         |  https://docs.oracle.com/javase/7/docs/api/java/awt/Rectangle.html
         |
         |          slope = height / width
         |
         |  @param None
         |
         | @return slope
         *-------------------------------------------------------------------*/
    public double getSlope()
    {
        double slope = NO_VALUE;
        if (!isEmpty())
        {
            slope = (getHeight() / getWidth());
        }
        else;
        return slope;
    }

    /*---------------------------- getMidPoint ----------------------------
         |  Method getMidPoint()
         |
         |Purpose: Finds the mid-point of the rectangle using method
         |         Math.round() from the Math class to roundup value to
         |         nearest Integer page A-25 of the API.
         |         Use of the Point class is required to save both coordinates
         |         as a Point. Center values for each axle are rounded up and
         |         cast to integers before they are passed as parameters of
         |         the object created from the Point class.
         |         First it makes sure width and height are different than 0
         |         using isEmpty() method from it superclass. Method returns
         |         true if the rectangle has no values, false otherwise.
         |         Refer to:
         |  https://docs.oracle.com/javase/7/docs/api/java/awt/Rectangle.html
         |         Result is cast to Integer because getWidth(), getX(), getY()
         |         and getHeight() methods return a floating point value.
         |
         |         xCoordinate = center of rectangle + “anchor” corner
         |                     = (int)(Math.round(getWidth() / 2) + getX())
         |
         |         yCoordinate = center of rectangle + “anchor” corner
         |                     = (int)(Math.round(getHeight() / 2) + getY())
         |
         |         midPoint    = (xCoordinate, yCoordinate)
         |
         |  @param None
         |
         | @return midPoint
         *-------------------------------------------------------------------*/
    public Point getMidPoint()
    {
        Point midPoint = new Point(ORIGIN, ORIGIN);
        if (!isEmpty())
        {
            int xCoordinate = (int)(Math.round(getWidth() / 2) + getX());
            int yCoordinate = (int)(Math.round(getHeight() / 2) + getY());
            midPoint = new Point(xCoordinate, yCoordinate);
        }
        else;
        return midPoint;
    }

    /*---------------------------- equals ----------------------------
         |  Method equals(Object rectangle)
         |
         |Purpose: Override existing equals method from the Rectangle class.
         |         Continue checking for the characteristics it checked before
         |         First, it checks if the object passed as parameters is an
         |         instance of the BetterRectangle class, then checks for
         |         the super.equals() to be true. Return true if both conditions
         |         are met, false otherwise.
         |
         |  @param rectangle
         |
         | @return midPoint
         *-------------------------------------------------------------------*/
    @Override
    public boolean equals(Object rectangle)
    {
        boolean equals = false;
        if (rectangle instanceof BetterRectangle)
        {
            if ((super.equals(rectangle)))
            {
                equals = true;
            }
            else;
        }
        else;
        return equals;
    }

    /*---------------------------- isProportional ----------------------------
         |  Method isProportional(BetterRectangle rectangle)
         |
         |Purpose: Checks if two rectangles have the same slope. Since slope
         |         is a floating point number, we compare the difference
         |         between them against a fixed THRESHOLD_CONDITION based on a
         |         decimal place accuracy of 2. Returns true if condition is
         |         satisfied, false otherwise.
         |
         |  @param rectangle
         |
         | @return proportional
         *-------------------------------------------------------------------*/
    public boolean isProportional(BetterRectangle rectangle)
    {
        boolean proportional = false;

        if(Math.abs(getSlope() - rectangle.getSlope()) < THRESHOLD_CONDITION)
        {
            proportional = true;
        }
        else;
        return proportional;
    }

    /*---------------------------- isEquivalent ----------------------------
         |  Method isEquivalent(BetterRectangle rectangle)
         |
         |Purpose: Checks if two rectangles have the same perimeter. It uses
         |         the == operator because getPerimeter() method return
         |         a primitive type value. Returns true if condition is
         |         satisfied, false otherwise.
         |
         |  @param rectangle
         |
         | @return equivalent
         *-------------------------------------------------------------------*/
    public boolean isEquivalent(BetterRectangle rectangle)
    {
        boolean equivalent = false;
        if (getPerimeter() == rectangle.getPerimeter())
        {
            equivalent = true;
        }
        else;
        return equivalent;
    }

    /*---------------------------- isSimilar ----------------------------
         |  Method isSimilar(BetterRectangle rectangle)
         |
         |Purpose: Checks if two rectangles have the same area. It uses
         |         the == operator because getArea() method return
         |         a primitive type value. Returns true if condition is
         |         satisfied, false otherwise.
         |
         |  @param rectangle
         |
         | @return similar
         *-------------------------------------------------------------------*/
    public boolean isSimilar(BetterRectangle rectangle)
    {
        boolean similar = false;
        if(getArea() == rectangle.getArea())
        {
            similar = true;
        }
        else;
        return similar;
    }

    /*---------------------------- isConcentric ----------------------------
         |  Method isConcentric(BetterRectangle rectangle)
         |
         |Purpose: Checks if two rectangles have the same mid-point . It uses
         |         the equals method because it is comparing the content of
         |         2 different objects. Returns true is condition is satisfied,
         |         false otherwise.
         |
         |  @param rectangle
         |
         | @return concentric
         *-------------------------------------------------------------------*/
    public boolean isConcentric(BetterRectangle rectangle)
    {
        boolean concentric = false;
        if(getMidPoint().equals(rectangle.getMidPoint()))
        {
            concentric = true;
        }
        else;
        return concentric;
    }

    /*---------------------------- setScaleBy ----------------------------
         |  Method setScaleBy(int scale)
         |
         |Purpose: Modify the size of a rectangle by a desired scale, this
         |         scale needs to be a positive integer number. First it
         |         checks if the parameter is an instance of Integer, then
         |         check if the rectangle to be modified is not empty,
         |         it makes sure width and height are different than 0
         |         using isEmpty() method from it superclass. Method returns
         |         true if the rectangle has no values, false otherwise.
         |         Refer to:
         |  https://docs.oracle.com/javase/7/docs/api/java/awt/Rectangle.html
         |         If both conditions are satisfied, the that integer is
         |         multiplied by the width and height in order
         |         to modify the size of the rectangle. Returns true is the
         |         re-size is made (positive integer number is passed), false
         |         otherwise.
         |
         |  @param scale
         |
         | @return scaleBy
         *-------------------------------------------------------------------*/
    public boolean setScaleBy(int scale)
    {
        boolean scaleBy = false;
        if (scale > NO_VALUE)
        {
            if (!isEmpty())
            {
                scaleBy = true;
                setSize((int)(getWidth() * scale), (int)(getHeight() * scale));
            }
            else;
        }
        else;
        return scaleBy;
    }

    /*---------------------------- toString ----------------------------
         |  Method toString()
         |
         |Purpose: Override toString() method from the java.awt.Rectangle
         |         class including new characteristics included in
         |         BetterRectangle class.
         |         Utilize substring method to extract part of the toString()
         |         method of it superclass, see 4.5.6 Sub-strings on
         |         Big Java: Early Objects, 5th Edition page 159.
         |         Utilize String.format() method from java.lang.String class
         |         to format the value of the slope to 2 decimal places.
         |         A constant TWO_DECIMAL_PLACES_FORMATTED and getSlope()
         |         are the parameters.
         |         Refer to Big Java: Early Objects, 5th Edition page A-27
         |
         |  @param None
         |
         | @return toString
         *-------------------------------------------------------------------*/
    @Override
    public String toString()
    {
        String toString =
                super.toString().substring(NO_VALUE, super.toString().length() - UNIT)
                + ", area=" + getArea() + ", perimeter=" + getPerimeter()
                + ", slope=" + String.format(TWO_DECIMAL_PLACES_FORMAT, getSlope())
                + ", mid-point=" + getMidPoint() + "]";

        return toString;
    }
}
