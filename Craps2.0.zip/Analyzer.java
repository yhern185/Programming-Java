/*=============================================================================
|   Source code: Analyzer.java
|        Author: Yonal Hernandez
|    Student ID: 6178656
|    Assignment: Program #3 Craps
|
|        Course: COP3337 Computer Programing II
|       Section: U02
|    Instructor: William Feild
|      Due Date: February 19, 2019 at the beginning of class
|
|	I hereby certify that this collective work is my own
|	and none of it is the work of any other person or entity.
|	_______Yonal Hernandez__________________________________
|
|      Language: Java
|   Compile/Run: Compile and run
| 	       javac Analyzer.java  Craps.java  Die.java
|	       java  Analyzer
|
|  +-----------------------------------------------------------------------------
|
|  Description: Program prompts user to enter an integer number that determine
|               the number of games of craps to play, integer is validated
|               and it needs to be between 1 an a million. Use methods from
|               Craps class to simulate the games of craps and collect data
|               from each game. Once it simulates the total number of games it
|               display a summary of the results in tables with a nice output.
|
|        Input: Prompt user for the number of games
|               to be analyzed, an integer between 1 and 1,000,000, inclusive.
|               Validate input guarding against non-numerical values and
|               numeric inbound.
|
|       Output: Provide the analysis of running a certain number of
|               games of Craps – presented in clear, aligned, readable and
|               attractive manner. The (win/lose) results of each game and the
|               number of rolls will be recorded by the Analyzer class in order
|               to facilitate an analysis of the game of Craps. Displayed
|               analysis will include data points for:
|               (1) total number of games played,
|               (2) total number of rolls for all games played,
|               (3) average length (in rolls) of the games played
|                   (total rolls/total games),
|               (4) longest game played (in rolls).
|               (5) total number of games won,
|               (6) expected probability of winning overall,
|               (7) outcome of winning overall (total wins/total games),
|               (8) total number of wins that occurred on the coming-out roll,
|               (9) total number of games that ended on the opening
|                   (coming —out) roll,
|               (10) expected probability of winning on the opening roll,
|               (11) outcome of winning on the coming-out roll
|                   (coming-out wins/coming-out games),
|               (12) expected probability of the games ending on the
|                   coming-out roll.
|               (13) outcome of games ending on the coming-out roll
|                   (coming-out games/total games),
|               (14) total number of games continuing-on after the
|                   coming-out roll (wins & losses),
|               (15) expected probability of the games continuing-on after
|                   the coming-out roll,
|               (16) outcome of games continuing-on after the coming-out roll
|                    ((total games - coming-out games)/total games),
|               (17) Summary tally of the number of rolls for each game to
|                    finish (1 to 21+),
|               * Coming-out games = total number of games that ended on the
|                  opening (coming-out) roll.
|
|      Process:
|               1. Create an object from the Scanner class to prompt and read
|                   read input from user.
|               2. Prompt user for desired number of games.
|               3. Validate input guarding against non-numerical values and
|                   numeric inbound.
|               4. Create a Craps object to use methods from the Craps class.
|               5. Run a for loop for desired number of games that simulates
|                   a single game of Craps and gather results for each
|                   individual game.
|               6. Display results in clear, aligned, readable and attractive
|                   manner. Results are presented in 4 sections.
|                       A. Summary of Game Statistics.
|                       B. Summary of Win Statistics.
|                       C. Summary of Ending Statistics.
|                       D. Summary of Game Lengths in Rolls.
|
|   Required Features Not Included:  None.
|
|   Known Bugs:
|  *===========================================================================*/

//Prompt and read input from user.
import java.util.Scanner;

public class Analyzer
{
    /*
    MIN_GAMES: Minimum number of games allowed to play.
    MAX_GAMES: Maximum number of games allowed to play.
    NO_GAMES: Initialize to 0 for comparison purposes.
    INCREMENT: Increments values by 1.
    NO_INCREMENT: Does not increment.
    LENGTH: Maximum result to check for amount of rolls per game.
    PROBABILITY_OF_WINNING: Based on the probability to win on the coming out roll
     add to the probability to won with every establish point before shooter hits
     a 7(NATURAL). For more information, please refer to:
     http://www.dehn.wustl.edu/~blake/courses/WU-Ed6021-2012-Summer/handouts/Expected_Value.pdf
    PROBABILITY_OF_WINNING_ON_OPENING_ROLL: probability of hit a 7 or 11 on the
     coming out roll. P(7) = 6/36, P(11) = 2/36. P(7) + P(11) = 0.22222222
    END_ON_OPENING_ROLL: probability of win or lose on the coming out roll. It
     is P(7) + P(11) + P(2) + P(3) + P(12) = 6/36 + 2/36 + 1/36 + 2/36 + 1/36 =
     3/9 = 0.33333333
    CONTINUING_ON_PROBABILITY: Expected probability of the games continuing on
     after the coming out roll. It is: 1 - probability of end the game on the
     opening roll. (1 - END_ON_OPENING_ROLL) = (1 - 1/3) = 2/3 = 0.666666
    */
    public static final int MIN_GAMES = 1;
    public static final int MAX_GAMES = 1000000;
    public static final int NO_GAMES = 0;
    public static final int INCREMENT = 1;
    public static final int NO_INCREMENT = 0;
    public static final int LENGTH = 21;
    public static final double PROBABILITY_OF_WINNING = 0.4929292929;
    public static final double PROBABILITY_OF_WINNING_ON_OPENING_ROLL = 0.22222222;
    public static final double END_ON_OPENING_ROLL = 0.3333;
    public static final double CONTINUING_ON_PROBABILITY = 0.666666;

    public static void main(String[] args)
    {
        /*
        totalWins: Hold value for total wins.
        totalRolls: Hold value for total loses.
        longestGame: Hold value for longest game in rolls.
        comingOutWins: Count wins on the coming out roll.
        comingOutLoses: Count loses on the coming out roll.
        continuingOnGames: Count number of games passing first roll.
        rollsPerGame: Array to storage a summary of amount of rolls.
        */
        int totalWins = NO_GAMES;
        int totalRolls = NO_GAMES;
        int longestGame = NO_GAMES;
        int comingOutWins = NO_GAMES;
        int comingOutLoses = NO_GAMES;
        int continuingOnGames = NO_GAMES;
        int[] rollsPerGame = new int[LENGTH];

        Scanner userInput = new Scanner(System.in);
        final int NUMBER_OF_GAMES = requestValidateNumberOfGames(userInput);

        Craps craps = new Craps();
        for (int gamesCounter = NO_GAMES; gamesCounter < NUMBER_OF_GAMES; gamesCounter++)
        {
            craps.playGame();
            totalRolls += incrementRolls(craps);
            longestGame = lengthOf1Game(craps, longestGame);
            totalWins += shooterWon(craps);
            comingOutWins += comingOutWon(craps);
            comingOutLoses += comingOutLose(craps);
            continuingOnGames += afterComingOutRoll(craps);
            rollsPerGame = rollsPerGameSummary(craps, rollsPerGame);
        }
        int comingOutGames = computeComingOutGames(comingOutWins, comingOutLoses);

        printGameStatistics(NUMBER_OF_GAMES, totalRolls, longestGame);
        printWinStatistics(totalWins, comingOutWins, comingOutGames, NUMBER_OF_GAMES);
        printEndingStatistics(continuingOnGames, NUMBER_OF_GAMES, comingOutGames);
        printGameLengthInRolls(rollsPerGame);
    }

    /*---------------------- printGameLengthInRolls ----------------------------
         |  Method printGameLengthInRolls(int[] rollsPerGame)
         |
         |Purpose: Print a summary tally of the number of rolls
         |         that each game needed to finish between 1 and 21+.
         |         If a game need more than 21 rolls, it will automatically
         |         added to the 21+ category (last index of the array).
         |
         |  @param rollsPerGame
         |
         |  @return None
         *-------------------------------------------------------------------*/
    private static void printGameLengthInRolls(int[] rollsPerGame)
    {
        System.out.println("Summary of Game Lengths in Rolls");
        System.out.println("+--------------------------------+");
        System.out.println("| Rolls        # of Games        |");
        System.out.println("+--------------------------------+");
        printContentOfSummaryTable(rollsPerGame);
        System.out.println("+--------------------------------+");
    }

    /*---------------------- printContentOfSummaryTable------------------------
         |  Method printContentOfSummaryTable(int[] rollsPerGame)
         |
         |Purpose: Print the content of the table using a for loop
         |         to access every element of the array. Keep track of the number
         |         of total games by adding all the elements in the array.
         |
         |  @param rollsPerGame
         |
         | @return None
         *-------------------------------------------------------------------*/
    private static void printContentOfSummaryTable(int[] rollsPerGame)
    {
        int totalGamesByRolls = NO_GAMES;
        int over21Rolls = (LENGTH - INCREMENT);
        for (int rollsCounter = NO_GAMES; rollsCounter < over21Rolls; rollsCounter++)
        {
            System.out.printf("| %2d %19d %9s %n", rollsCounter + INCREMENT,
                           rollsPerGame[rollsCounter], "|");
            totalGamesByRolls += rollsPerGame[rollsCounter];
        }
        System.out.printf("| 21+ %18d %9s %n", rollsPerGame[over21Rolls], "|");
        totalGamesByRolls += rollsPerGame[over21Rolls];

        System.out.println("+--------------------------------+");
        System.out.printf("| Total %16d %9s %n", totalGamesByRolls, "|");
    }

    /*---------------------- computeComingOutGames ----------------------------
         |  Method computeComingOutGames(int comingOutWins, int comingOutLoses)
         |
         |Purpose: Compute coming out games. Adding coming out wins and
         |         coming out loses.
         |
         |  @param comingOutWins
         |  @param comingOutLoses
         |
         | @return comingOutGames
         *-------------------------------------------------------------------*/
    private static int computeComingOutGames(int comingOutWins, int comingOutLoses)
    {
        int comingOutGames = (comingOutWins + comingOutLoses);
        return comingOutGames;
    }

    /*---------------------- printEndingStatistics ----------------------------
         |  Method printEndingStatistics(int continuingOnGames, int NUMBER_OF_GAMES,
         |                                   int comingOutGames)
         |
         |Purpose: Print a summary table of the ending statistics. Use a constant,
         |         CONTINUING_ON_PROBABILITY. Display results for the
         |         continuing-on games, results are floating point values
         |         rounded to 4 decimal places.
         |         You can refer to: http://www.dehn.wustl.edu/~blake/courses
         |         /WU-Ed6021-2012-Summer/handouts/Expected_Value.pdf
         |         for more information about expected values on a game of Craps.
         |Where:
         |  CONTINUING_ON_PROBABILITY: Expected probability of the games continuing on
         |   after the coming out roll. 1 - probability of end the game on the opening
         |   roll. (1 - END_ON_OPENING_ROLL) = (1 - 1/3) = 2/3 = 0.666666
         |
         |  @param continuingOnGames
         |  @param NUMBER_OF_GAMES
         |  @param comingOutGames
         |
         |  @return None
         *-------------------------------------------------------------------*/
    public static void printEndingStatistics(int continuingOnGames, int NUMBER_OF_GAMES,
                                             int comingOutGames)
    {
        double continuingOnOutcome = computeContinuingOnOutcome(NUMBER_OF_GAMES,
                comingOutGames);
        System.out.println("Summary of Ending Statistics");
        System.out.println("+-----------------------------------------------------------------+");
        System.out.println("| Stat                  Games         Outcome        Expected     |");
        System.out.println("+-----------------------------------------------------------------+");
        System.out.printf("| Continuing-On Games %6d (14) %9.4f (16) %9.4f (15) %3s %n", +
                        continuingOnGames, continuingOnOutcome, CONTINUING_ON_PROBABILITY, "|");
        System.out.println("+-----------------------------------------------------------------+");
    }

    /*---------------------- computeContinuingOnOutcome ----------------------------
             |  Method computeContinuingOnOutcome(int NUMBER_OF_GAMES,
             |                                      int comingOutGames)
             |
             |Purpose: Compute the outcome of the continuing-on games. Save
             |         integers to double to avoid integer division. Use provided
             |         formula: ((numberOfGames - comingOutGames) / numberOfGames)
             |
             |  @param NUMBER_OF_GAMES
             |  @param comingOutGames
             |
             | @return continuingOnOutcome
             *-------------------------------------------------------------------*/
    private static double computeContinuingOnOutcome(int NUMBER_OF_GAMES, int comingOutGames)
    {
        double comingOutGamesDouble = comingOutGames;
        double numberOfGames = NUMBER_OF_GAMES;
        double continuingOnOutcome = ((numberOfGames - comingOutGamesDouble) / numberOfGames);
        return continuingOnOutcome;
    }

    /*---------------------- printWinStatistics ----------------------------
         |  Method printWinStatistics(int totalWins, int comingOutWins,
         |                                 int comingOutLoses, int NUMBER_OF_GAMES)
         |
         |Purpose: Print a summary table of the win statistics. Use some constants,
         |         as the PROBABILITY_OF_WINNING, PROBABILITY_OF_WINNING_ON_OPENING_ROLL
         |         END_ON_OPENING_ROLL. Save integers to double for the necessity of
         |         express result in floating point values.
         |         You can refer to: http://www.dehn.wustl.edu/~blake/courses
         |         /WU-Ed6021-2012-Summer/handouts/Expected_Value.pdf
         |         for more information about expected values on a game of Craps.
         |Where:
         |  PROBABILITY_OF_WINNING: Based on the probability to win on the coming out roll
         |   add to the probability to won with every establish point before shooter hits
         |   a 7(NATURAL). P(7) = 6/36, P(11) = 2/36, P(4 before 7) = 1/36,
         |   P(5 before 7) = 2/45, P(6 before 7) = 25/396, P(8 before 7) = 25/396,
         |   P(9 before 7) = 2/45, P(10 before 7) = 1/36.
         |   P(WINNING) = Addition of all probabilities above = 0.4929292929
         |  PROBABILITY_OF_WINNING_ON_OPENING_ROLL: probability of hit a 7 or 11 on the
         |   coming out roll. P(7) = 6/36, P(11) = 2/36. P(7) + P(11) = 0.2222
         |  END_ON_OPENING_ROLL: probability of win or lose on the coming out roll. It
         |   is P(7) + P(11) + P(2) + P(3) + P(12) = 6/36 + 2/36 + 1/36 + 2/36 + 1/36 =
         |   3/9 = 0.33333333
         |
         |  @param totalWins
         |  @param comingOutWins
         |  @param comingOutGames
         |  @param NUMBER_OF_GAMES
         |
         |  @return None
         *-------------------------------------------------------------------*/
    public static void printWinStatistics(int totalWins, int comingOutWins,
                                           int comingOutGames, int NUMBER_OF_GAMES)
    {
        double winningOverall = computeWinningOverall(totalWins, NUMBER_OF_GAMES);
        double comingOutWinsOutcome = computeComingOutWinsOutcome(comingOutWins,
                comingOutGames);
        double comingOutOutcome = computeComingOutOutcome(comingOutGames, NUMBER_OF_GAMES);
        double winOnOpeningRoll = computeWinOnOpeningRoll();

        System.out.println("Summary of Win Statistics");
        System.out.println("+-----------------------------------------------------------------+");
        System.out.println("| Stat                  Games         Outcome        Expected     |");
        System.out.println("+-----------------------------------------------------------------+");
        System.out.printf("| Total Wins %15d %s %10.4f %s %10.4f %s %4s %n", +
                totalWins, "(5)", winningOverall, "(7)", PROBABILITY_OF_WINNING,
                "(6)", "|");
        System.out.printf("| Coming-Out Wins %10d %s %10.4f %s %9.4f %s %3s %n", +
                        comingOutWins, "(8)", comingOutWinsOutcome, "(11)",
                        winOnOpeningRoll, "(10)", "|");
        System.out.printf("| Coming-Out Games %9d %s %10.4f %s %9.4f %s %3s %n", +
                        comingOutGames, "(9)", comingOutOutcome,
                        "(13)", END_ON_OPENING_ROLL, "(12)", "|");
        System.out.println("+-----------------------------------------------------------------+");
    }

    /*---------------------- computeWinOnOpeningRoll ----------------------------
         |  Method computeWinOnOpeningRoll()
         |
         |Purpose: Compute the expected probability of winning on the opening roll
         |         based on the probability of the coming out games.
         |
         |  @param None
         |
         | @return winOnOpeningRoll
         *-------------------------------------------------------------------*/
    private static double computeWinOnOpeningRoll()
    {
        double winOnOpeningRoll =
                    (PROBABILITY_OF_WINNING_ON_OPENING_ROLL / END_ON_OPENING_ROLL);

        return winOnOpeningRoll;
    }

    /*---------------------- computeComingOutOutcome ----------------------------
         |  Method computeComingOutOutcome(int comingOutGames, int NUMBER_OF_GAMES)
         |
         |Purpose: Compute the outcome of the games ending on the coming out
         |         roll. Coming out games divided by the total games.
         |         Since NUMBER_OF_GAMES, comingOutWins and comingOutLoses
         |         are integers, method  save them into variables type double
         |         to avoid integer division. Coming out games is the addition
         |         of coming out wins and the coming out games.
         |
         |  @param comingOutGames
         |  @param NUMBER_OF_GAMES
         |
         | @return endOnTheComingOut
         *-------------------------------------------------------------------*/
    private static double computeComingOutOutcome(int comingOutGames, int NUMBER_OF_GAMES)
    {
        double comingOutGamesDouble = comingOutGames;
        double totalGames = NUMBER_OF_GAMES;
        double endOnTheComingOut = (comingOutGamesDouble / totalGames);
        return endOnTheComingOut;
    }

    /*---------------------- computeComingOutWinsOutcome ----------------------------
         |  Method computeComingOutWinsOutcome(int comingOutWins, int comingOutGames)
         |
         |Purpose: Compute the outcome of winning on the coming out roll.
         |         coming out wins divided by the coming out games. First,
         |         check the value of the comingOutGames comparing it to
         |         0 to avoid division by 0.
         |         Since comingOutWins and comingOutLoses are integers,
         |         method save them into variables type double to avoid
         |         integer division. Coming out games is the addition of
         |         coming out wins and the coming out games
         |
         |  @param comingOutWins
         |  @param comingOutGames
         |
         | @return outcomeOfWinningOnTheComingOut
         *-------------------------------------------------------------------*/
    private static double computeComingOutWinsOutcome(int comingOutWins, int comingOutGames)
    {
        double outcomeOfWinningOnTheComingOut = NO_GAMES;
        if(comingOutGames != NO_GAMES)
        {
            double doubleComingOutWins = comingOutWins;
            double comingOutGamesDouble = comingOutGames;
            outcomeOfWinningOnTheComingOut = (doubleComingOutWins / comingOutGamesDouble);
        }
        else
        {

        }
        return outcomeOfWinningOnTheComingOut;
    }

    /*---------------------- computeWinningOverall ----------------------------
         |  Method computeWinningOverall(int totalWins, int NUMBER_OF_GAMES)
         |
         |Purpose: Compute the outcome of winning overall. Total number
         |         number of wins divided by the total number of games.
         |         Since totalWins and NUMBER_OF_GAMES are integers,
         |         method save them into variables type double to avoid
         |         integer division.
         |
         |  @param totalWins
         |  @param NUMBER_OF_GAMES
         |
         | @return winningOverall
         *-------------------------------------------------------------------*/
    private static double computeWinningOverall(int totalWins, int NUMBER_OF_GAMES)
    {
        double wins = totalWins;
        double numberOfGames = NUMBER_OF_GAMES;
        double winningOverall = (wins / numberOfGames);
        return winningOverall;
    }

    /*---------------------- printGameStatistics ----------------------------
         |  Method printGameStatistics(int NUMBER_OF_GAMES,
         |                                  int totalRolls, int longestGame)
         |
         |Purpose: Print a summary table of the game statistics.
         |
         |  @param NUMBER_OF_GAMES
         |  @param totalRolls
         |  @param longestGame
         |
         | @return None
         *-------------------------------------------------------------------*/
    public static void printGameStatistics(int NUMBER_OF_GAMES,
                                            int totalRolls, int longestGame)
    {
        double averageLength = computeAverageLength(totalRolls, NUMBER_OF_GAMES);

        System.out.println("\nSummary of Game Statistics");
        System.out.println("+----------------------------------+");
        System.out.printf("| (1) Total Games   %14d | %n", NUMBER_OF_GAMES);
        System.out.printf("| (2) Total Rolls   %14d | %n", totalRolls);
        System.out.printf("| (3) Average Rolls %14.4f | %n", averageLength);
        System.out.printf("| (4) Longest Game  %14d | %n", longestGame);
        System.out.println("+----------------------------------+");
    }

    /*---------------------- computeAverageLength ----------------------------
         |  Method computeAverageLength(double totalRolls, int NUMBER_OF_GAMES)
         |
         |Purpose: Compute the average length in rolls of the games played.
         |         Total rolls divided by the total of the games.
         |         Save integers to double to avoid integer division.
         |
         |  @param totalRolls
         |  @param NUMBER_OF_GAMES
         |
         | @return average
         *-------------------------------------------------------------------*/
    private static double computeAverageLength(double totalRolls, int NUMBER_OF_GAMES)
    {
        double totalRollToDouble = totalRolls;
        double numberOfGames = NUMBER_OF_GAMES;
        double average = (totalRollToDouble/numberOfGames);
        return average;
    }

    /*---------------------- rollsPerGameSummary ----------------------------
         |  Method rollsPerGameSummary(Craps craps, int[] rollsPerGame)
         |
         |Purpose: Save the amount of times the game ended with certain
         |         amount of rolls (between 1 and 21). In case the game
         |         ended with more than 21 rolls it will be saved as 21.
         |         Data is being saved into an Array of type int.
         |
         |  @param craps
         |  @param rollsPerGame
         |
         | @return rollsPerGame
         *-------------------------------------------------------------------*/
    public static int[] rollsPerGameSummary(Craps craps, int[] rollsPerGame)
    {

        int roll = craps.getNumberOfRolls();
        if (roll > LENGTH)
        {
            roll = LENGTH - 1;
        }
        else
        {
            roll -= INCREMENT;
        }
        rollsPerGame[roll]++;
        return rollsPerGame;
    }

    /*---------------------- afterComingOutRoll ------------------------------
         |  Method afterComingOutRoll(Craps craps)
         |
         |Purpose: Check if the game continue after the first roll calling
         |         getPoint() method from Craps class and comparing that
         |         value with 0. If the condition is true it increments
         |         the number of continuingOnGames.
         |
         |  @param craps
         |
         | @return continuingOnGames
         *-------------------------------------------------------------------*/
    public static int afterComingOutRoll(Craps craps)
    {
        int afterComingOutRoll = NO_GAMES;
        if (craps.getPoint() > NO_GAMES)
        {
            afterComingOutRoll = INCREMENT;
        }
        else
        {
            afterComingOutRoll = NO_INCREMENT;
        }
        return afterComingOutRoll;
    }

    /*---------------------- comingOutLose ---------------------------------
         |  Method comingOutLose(Craps craps)
         |
         |Purpose: Check if the shooter lose on the coming out roll by calling
         |         isComingOutLose() method from Craps class. If return true
         |         it increments the number of comingOutLoses.
         |
         |  @param craps
         |
         | @return comingOutLoses
         *-------------------------------------------------------------------*/
    public static int comingOutLose(Craps craps)
    {
        int comingOutLose = NO_GAMES;
        if (craps.isComingOutLose())
        {
            comingOutLose = INCREMENT;
        }
        else
        {
            comingOutLose = NO_INCREMENT;
        }
        return comingOutLose;
    }

    /*---------------------- comingOutWon ---------------------------------
         |  Method comingOutWon(Craps craps)
         |
         |Purpose: Check if the shooter won on the coming out roll by calling
         |         isComingOutWon() method from Craps class. If return true
         |         it increments the number of comingOutWins.
         |
         |  @param craps
         |
         | @return comingOutWon
         *-------------------------------------------------------------------*/
    public static int comingOutWon(Craps craps)
    {
        int comingOutWon = NO_GAMES;
        if(craps.isComingOutWon())
        {
            comingOutWon = INCREMENT;
        }
        else
        {
            comingOutWon = NO_INCREMENT;
        }
        return comingOutWon;
    }

    /*---------------------- shooterWon---------------------------------
         |  Method shooterWon(Craps craps)
         |
         |Purpose: Check if the shooter won or not by calling
         |         isShooterWon() method from Craps class. If return true
         |         it increments the number of wins.
         |
         |  @param craps
         |
         | @return shooterWon
         *-------------------------------------------------------------------*/
    public static int shooterWon(Craps craps)
    {
        int shooterWon = NO_GAMES;
        if (craps.isShooterWon())
        {
            shooterWon = INCREMENT;
        }
        else
        {
            shooterWon = NO_INCREMENT;
        }
        return shooterWon;
    }

    /*---------------------- lengthOf1Game---------------------------------
         |  Method lengthOf1Game(Craps craps, int longestGame)
         |
         |Purpose: Keep track of the longest game in rolls by comparing each
         |         game with the longest one saved in variable longest game.
         |         If condition is true longestGame variable is updated in with
         |         new longest game, stay the same otherwise.
         |
         |  @param craps
         |  @param longestGame
         |
         | @return longestGame
         *-------------------------------------------------------------------*/
    public static int lengthOf1Game(Craps craps, int longestGame)
    {
        int thisGame = NO_GAMES;
        thisGame = craps.getNumberOfRolls();
        if (longestGame < thisGame)
        {
            longestGame = thisGame;
        }
        else
        {

        }
        return longestGame;
    }

    /*---------------------- incrementRolls---------------------------------
         |  Method incrementRolls(Craps craps)
         |
         |Purpose: Increment number of rolls per game to get the total
         |         number of rolls at the end of all games.
         |
         |  @param craps
         |
         | @return totalRolls
         *-------------------------------------------------------------------*/
    public static int incrementRolls(Craps craps)
    {
        int totalRolls = NO_GAMES;
        totalRolls = craps.getNumberOfRolls();
        return totalRolls;
    }

    /*---------------------- requestValidateNumberOfGames------------------
         |  Method requestValidateNumberOfGames(Scanner userInput)
         |
         |Purpose: Prompt user for number of games to play. Need to
         |         be an integer number between 1 and 1 million. Method
         |         protects against non-numerical input and arithmetic
         |         inbound.
         |
         |  @param userInput
         |
         | @return numberOfGames
         *-------------------------------------------------------------------*/
    public static int requestValidateNumberOfGames(Scanner userInput)
    {
        int numberOfGames = NO_GAMES;
        boolean validInteger = false;
        System.out.println("Please enter number of games to be played." +
                "It has to be an integer number between: " + MIN_GAMES
                + " and " + MAX_GAMES + ".");
        do
        {
            userInput.hasNextInt();
            if (userInput.hasNextInt())
            {
                numberOfGames = userInput.nextInt();
                if (numberOfGames < MIN_GAMES || numberOfGames > MAX_GAMES)
                {
                    System.out.println("Invalid number of games. Try Again.");
                }
                else
                {
                    validInteger = true;
                }
            }
            else
            {
                userInput.next();
                System.out.println("Invalid number of games. Try Again.");
            }
        }
        while(!validInteger);
        return numberOfGames;
    }
}
