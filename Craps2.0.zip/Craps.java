/*=======================================================================
|     Source code: Analyzer.java
|           Class: Craps.java
|          Author: Yonal Hernandez
|      Student ID: 6178656
|      Assignment: Program #3 Craps
|
|          Course: COP3337 Computer Programing II
|         Section: U02
|      Instructor: William Feild
|        Due Date: February 19, 2019 at the beginning of class
|
|	I hereby certify that this collective work is my own
|	and none of it is the work of any other person or entity.
|	_______Yonal Hernandez__________________________________
|
|        Language: Java
|     Compile/Run: Compile
| 	         javac Craps.java
|
|         Purpose: Play a single game of Craps and nothing else.
|                  Check if the shooter won or lose and how many
|                  rolls it took. Is in charge of reset the game
|                  parameters before every game and uses the Die class.
|                  Use terminology from the craps game, visit:
|                  https://en.wikipedia.org/wiki/Glossary_of_craps_terms
|                  for more information about it.
|
|   Inherits From: None
|
|      Interfaces: None
|
|  +-----------------------------------------------------------------------
|
|       Constants: final int NO_ROLL = 0;
|                   Fixed value use to reset values.
|                  final int SNAKE_EYES = 2;
|                   Craps term for the number 2.
|                  final int ACE_DEUCE = 3;
|                   Craps term for the number 3.
|                  final int NATURAL = 7;
|                   Craps term for the number 7.
|                  final int YO_LEVEN = 11;
|                   Craps term for the number 11.
|                  final int BOX_CARS = 12;
|                   Craps term for the number 12.
|
| +-----------------------------------------------------------------------
|
|    Constructors: Craps()
|
|   Class Methods: None.
|
|Instance Methods: resetGame(): return None
|                  playGame(): return None
|                  comingOutRoll(): return None
|                  continuingOnGames(): return None
|                  getNumberOfRolls(): return numberOfRolls
|                  getPoint(): return point
|                  isShooterWon(): return shooterWon
|                  isComingOutWon(): return comingOutWon
|                  isComingOutLose(): return comingOutLose
|
|  *===========================================================================*/

public class Craps
{
    final int NO_ROLL = 0;
    final int SNAKE_EYES = 2;
    final int ACE_DEUCE = 3;
    final int NATURAL = 7;
    final int YO_LEVEN = 11;
    final int BOX_CARS = 12;

    /*
    numberOfRolls: Hold value for number of rolls in a single game.
    upwardFacesAdded: Hold value for the addition of 2 consecutive single roll.
    point: Established point for games passing the coming out roll.
    shooterWon: Check if the shooter won or lose.
    gameFinished: Determine is the game is over.
    comingOutWon: Check if game is won on the coming out roll.
    comingOutLose: Check if game is lose on the coming out roll.
    die: Object to use Die class methods using default constructor.
    */
    private int numberOfRolls = NO_ROLL;
    private int upwardFacesAdded = NO_ROLL;
    private int point = NO_ROLL;
    private boolean shooterWon = false;
    private boolean gameFinished = false;
    private boolean comingOutWon = false;
    private boolean comingOutLose = false;
    Die die = new Die();

    /*---------------------------- Craps ----------------------------
         |  Method Craps()
         |
         |Purpose: Default constructor for my Craps class.
         |         It reset the game leaving it ready to play.
         |
         |  @param None
         |
         | @return None
         *-------------------------------------------------------------------*/
    public Craps()
    {
        resetGame();
    }

    /*---------------------------- resetGame ----------------------------
         |  Method resetGame()
         |
         |Purpose: Set every parameter of the game to the start position
         |         preparing conditions for a new game.
         |
         |  @param None
         |
         | @return None
         *-------------------------------------------------------------------*/
    public void resetGame()
    {
        numberOfRolls = NO_ROLL;
        upwardFacesAdded = NO_ROLL;
        point = NO_ROLL;
        shooterWon = false;
        gameFinished = false;
        comingOutWon = false;
        comingOutLose = false;
    }

    /*---------------------------- playGame ----------------------------
         |  Method playGame()
         |
         |Purpose: Simulates a single game of Craps using the Die class.
         |         Use method resetGame() to initialize variables.
         |         Use method comingOutRoll() to simulate the initial roll.
         |         Use method continuingOnGames() to establish the point
         |         in those games that not finished on the coming out roll.
         |
         |  @param None
         |
         | @return None
         *-------------------------------------------------------------------*/
    public void playGame()
    {
        resetGame();
        comingOutRoll();
        continuingOnGames();
    }

    /*---------------------------- continuingOnGames ----------------------------
         |  Method continuingOnGames()
         |
         |Purpose: Simulates the continuation of a single game of craps
         |         that do not finish on the coming out roll.
         |         It establish a point and after that, shooter keep
         |         shooting until he/she gets a 7 (NATURAL) where it
         |         loses, or it gets the point and wins the game.
         |         constants are declared to compare the result from the
         |         added upward faces. Craps terms are as follows:
         |
         |         final int NATURAL = 7;
         |
         |  @param None
         |
         | @return None
         *-------------------------------------------------------------------*/
    private void continuingOnGames()
    {
        while (! gameFinished)
        {
            upwardFacesAdded = die.rollDie() + die.rollDie();
            numberOfRolls++;
            if (upwardFacesAdded == NATURAL)
            {
                gameFinished = true;
            }
            else if (upwardFacesAdded == point)
            {
                shooterWon = true;
                gameFinished = true;
            }
            else
            {

            }
        }
    }

    /*---------------------------- comingOutRoll ----------------------------
         |  Method comingOutRoll()
         |
         |Purpose: Simulates the initial or coming out roll in a single game
         |         of Craps. If shooter gets a 7(NATURAL) or 11(YO_LEVEN)
         |         it wins, if it gets a 2(SNAKE_EYES), 3(ACE_DEUCE) or a
         |         12(BOX_CARS) it loses. In case it gets any other number
         |         (4,5,6,8,9,10), that number will establish a point and
         |         the game will continue.
         |         constants are declared to compare the result from the
         |         added upward faces. Craps terms are as follows:
         |
         |         final int SNAKE_EYES = 2;
         |         final int ACE_DEUCE = 3;
         |         final int NATURAL = 7;
         |         final int YO_LEVEN = 11;
         |         final int BOX_CARS = 12;
         |
         |  @param None
         |
         | @return None
         *-------------------------------------------------------------------*/
    private void comingOutRoll()
    {
        upwardFacesAdded = die.rollDie() + die.rollDie();
        numberOfRolls++;
        if (upwardFacesAdded == NATURAL || upwardFacesAdded == YO_LEVEN)
        {
            shooterWon = true;
            comingOutWon = true;
            gameFinished = true;
        }
        else if (upwardFacesAdded == SNAKE_EYES || upwardFacesAdded == ACE_DEUCE
                || upwardFacesAdded == BOX_CARS)
        {
            comingOutLose = true;
            gameFinished = true;
        }
        else
        {
            point = upwardFacesAdded;
        }
    }

    /*---------------------------- getNumberOfRolls ----------------------------
         |  Method getNumberOfRolls()
         |
         |Purpose: Provides total number of rolls in a single game.
         |
         |  @param None
         |
         | @return numberOfRolls
         *-------------------------------------------------------------------*/
    public int getNumberOfRolls()
    {
        return numberOfRolls;
    }

    /*---------------------------- getPoint ----------------------------
         |  Method getPoint()
         |
         |Purpose: Provides point value in case game pass the coming out
         |         roll.
         |
         |  @param None
         |
         | @return point
         *-------------------------------------------------------------------*/
    public int getPoint()
    {
        return point;
    }

    /*---------------------------- isShooterWon ----------------------------
         |  Method isShooterWon()
         |
         |Purpose: Return true if player won the game, false otherwise.
         |
         |  @param None
         |
         | @return shooterWon
         *-------------------------------------------------------------------*/
    public boolean isShooterWon()
    {
        return shooterWon;
    }

    /*---------------------------- isComingOutWon ----------------------------
         |  Method isComingOutWon()
         |
         |Purpose: Return true if player won the game on the coming out roll
         |         (first roll), false otherwise.
         |
         |  @param None
         |
         | @return comingOutWon
         *-------------------------------------------------------------------*/
    public boolean isComingOutWon()
    {
        return comingOutWon;
    }

    /*---------------------------- isComingOutLose ----------------------------
         |  Method isComingOutWon()
         |
         |Purpose: Return true if player lose the game on the coming out roll
         |         (first roll), false otherwise.
         |
         |  @param None
         |
         | @return isComingOutLose
         *-------------------------------------------------------------------*/
    public boolean isComingOutLose()
    {
        return comingOutLose;
    }
}
