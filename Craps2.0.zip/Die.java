/*=======================================================================
|     Source code: Analyzer.java
|           Class: Die.java
|          Author: Yonal Hernandez
|      Student ID: 6178656
|      Assignment: Program #3 Craps
|
|          Course: COP3337 Computer Programing II
|         Section: U02
|      Instructor: William Feild
|        Due Date: February 19, 2019 at the beginning of class
|
|	I hereby certify that this collective work is my own
|	and none of it is the work of any other person or entity.
|	_______Yonal Hernandez__________________________________
|
|        Language: Java
|     Compile/Run: Compile
| 	         javac Die.java
|
|         Purpose: Generic Die class that creates a Die from a desired
|                  number of sides between 2 and 100. Any value below
|                  2 will be round 2, any value above 100 will be
|                  round to 100. Default number of sides is set to 6.
|
|   Inherits From: None
|
|      Interfaces: None
|
|  +-----------------------------------------------------------------------
|
|       Constants: final int SPOT_1 = 1;
|                   Minimum possible number in a die.
|                  final int MIN_SIDES = 2;
|                   Minimum sides allowed.
|                  final int MAX_SIDES = 100;
|                   Maximum sides allowed.
|                  final int DEFAULT_SIDES = 6;
|                   Default number of sides is none is specified.
|                  final int NO_VALUE = 0;
|                   Default value to initialize variables.
| +-----------------------------------------------------------------------
|
|    Constructors: public Die()
|                  public Die(int sides)
|
|   Class Methods: None.
|
|Instance Methods: public int rollDie(): return singleDie;
|
|  *===========================================================================*/

//Random class, produces numbers that appear to be completely random.
import java.util.Random;

public class Die
{
    final int SPOT_1 = 1;
    final int MIN_SIDES = 2;
    final int MAX_SIDES = 100;
    final int DEFAULT_SIDES = 6;
    final int NO_VALUE = 0;

    /*
    sides: Hold value for defined number of sides.
    singleDie: Hold value for generated number of a single dice.
     */
    private int sides = NO_VALUE;
    private int singleDie = NO_VALUE;

    /*---------------------------- Die ----------------------------
        |  Method Die()
        |
        |Purpose: Default constructor for my Die class. Set the numbers of
        |         sides to 6.
        |
        |  where: DEFAULT_SIDES = 6
        |
        |  @param None
        |
        | @return sides
        *-------------------------------------------------------------------*/
    public Die()
    {
        sides = DEFAULT_SIDES;
    }

    /*---------------------------- Die ----------------------------
         |  Method Die(int sides)
         |
         |Purpose: Constructor for my Die class. Set the numbers of sides
         |         to the desired parameter in the range 2 to 100. In case
         |         parameter is out of range, will be set to 2 if value
         |         is below 2 or it will be set to 100 if value is above a 100.
         |
         |  where: MIN_SIDES = 2
         |         MAX_SIDES = 100;
         |
         |  @param sides
         |
         | @return sides
         *-------------------------------------------------------------------*/
    public Die(int sides)
    {
        if (sides < MIN_SIDES)
        {
            this.sides = MIN_SIDES;
        }
        else if (sides > MAX_SIDES)
        {
            this.sides = MAX_SIDES;
        }
        else
        {
            this.sides = sides;
        }
    }

    /*---------------------------- rollDie ----------------------------
         |  Method rollDie()
         |
         |Purpose: Simulates the roll of a die. Use an object from the
         |         Random class (dieGenerator), and the method nextInt(n).
         |         Where n = sides. This method produces numbers
         |         that appear to be completely random between 0 and sides
         |         not inclusive. After that it add one to the random number
         |         because 1 is the minimum possible number in a die. Example
         |         to be found on Big Java: Early Objects, 5th Edition /283.
         |         Returns the simulated value for a single die.
         |
         |  where: SPOT_1 = 1
         |
         |  @param None
         |
         | @return singleDie
         *-------------------------------------------------------------------*/
    public int rollDie()
    {
        Random dieGenerator = new Random();
        singleDie = SPOT_1 + dieGenerator.nextInt(sides);
        return singleDie;
    }
}
