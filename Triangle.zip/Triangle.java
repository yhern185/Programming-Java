/*=======================================================================
|     Source code: TriangleTester.java
|           Class: Triangle.java
|          Author: Yonal Hernandez
|      Student ID: 6178656
|      Assignment: Program #2 Triangle
|
|          Course: COP3337 Computer Programing II
|         Section: U02
|      Instructor: William Feild
|        Due Date: February 07, 2019 at the beginning of class
|
|	I hereby certify that this collective work is my own
|	and none of it is the work of any other person or entity.
|	_______Yonal Hernandez__________________________________
|
|        Language: Java
|     Compile/Run: Compile
| 	         javac Triangle.java
|
|         Purpose: This class is use to save the coordinates of a triangle
|                  into points using the Point2D class from the Math library
|                  provided by Java. It computes the length of the sides of
|                  the triangle and the angles of the triangle. Moreover,
|                  it computes the perimeter and area of the triangle, and uses
|                  two utility methods to say if the triangle is equilateral or
|                  right-angled.
|
|   Inherits From: None
|
|      Interfaces: None
|
|  +-----------------------------------------------------------------------
|
|       Constants: final double BASE_10 = 10.
|                   Base of exponent to elevate in base 10.
|                  final int POW_OF_2 = 2
|                   Avoid magic number 2 elevating to the power of 2.
|                  final int NO_LENGTH = 0.
|                   Avoid magic number when comparing length of sides.
|                  final int THRESHOLD_ACCURACY = - 4.
|                   Decimal places accuracy to check if values are almost the same.
|                  final double NINETY_DEGREES = 90.
|                   Value to compare a 90 degrees angle.
|                  final double THRESHOLD_CONDITION = Math.pow(BASE_10, THRESHOLD_ACCURACY).
|                   Fixed decimal places accuracy to check if numbers are almost the same.
|
| +-----------------------------------------------------------------------
|
|    Constructors: public Triangle(Point2D point1, Point2D point2, Point2D point3)
|                  public Triangle(double x1, double y1, double x2, double y2, double x3, double y3)
|
|   Class Methods: None.
|
|Instance Methods: public double getSide1(): return lengthOfSide1.
|                  public double getSide2(): return lengthOfSide2.
|                  public double getSide3(): return lengthOfSide3.
|                  public double getAngle1(): return angle1.
|                  public double getAngle2(): return angle2.
|                  public double getAngle3(): return angle3.
|                  public double getPerimeter(): return perimeterOfTriangle.
|                  public double getArea(): return areaOfTriangle.
|                  public boolean testEquilateral(): return equilateralTriangle.
|                  public boolean rightAngled(): return rightAngledTriangle.
|
|  *===========================================================================*/


import java.lang.Math;//Allows the use of the Math Class.
import java.awt.geom.Point2D;//Allows the use of the Point Class.

public class Triangle
{
    final int POW_OF_2 = 2;//Avoid magic number 2 elevating to the power of 2.
    final double BASE_10 = 10;//Elevate in base 10.
    final int NO_LENGTH = 0;//Avoid magic number 0 in the comparison.
    final int THRESHOLD_ACCURACY = - 4;//Decimal places accuracy.
    final double NINETY_DEGREES = 90;//Value to compare a 90 degrees angle.
    final double THRESHOLD_CONDITION = Math.pow(BASE_10, THRESHOLD_ACCURACY);

    private Point2D point1;//Save coordinates for Point 1.
    private Point2D point2;//Save coordinates for Point 2.
    private Point2D point3;//Save coordinates for Point 3.

    /*---------------------------- Triangle ----------------------------
        |  Method Triangle(Point2D pointA, Point2D pointB, Point2D pointC)
        |
        |Purpose: It is a constructor for my Triangle class, accepting parameters
        |         in the form of points using Point2D class provided by the java
        |         library in the Appendix D (A17-18) in the text
        |         (Big Java: Early Objects, 5th Edition).
        |
        |  @param  pointA
        |  @param  pointB
        |  @param  pointC
        |
        |  @return  point1
        |  @return  point2
        |  @return  point3
        *-------------------------------------------------------------------*/
    public Triangle(Point2D pointA, Point2D pointB, Point2D pointC)
    {
        point1 = pointA;
        point2 = pointB;
        point3 = pointC;
    }

    /*---------------------------- Triangle ----------------------------
        |  Method Triangle(double x1, double y1, double x2, double y2, double x3, double y3)
        |
        |Purpose: It is a constructor for my Triangle class, accepting parameters
        |         in the form of coordinates. By using Point2D class provided by
        |         the java library in the Appendix D (A17-18) in the text
        |         (Big Java: Early Objects, 5th Edition). It will save those
        |         coordinates into points.
        |         Where: x1 = coordinateX1
        |                y1 = coordinateY1
        |                x2 = coordinateX2
        |                y2 = coordinateY2
        |                x3 = coordinateX3
        |                y3 = coordinateY3
        |
        |  @param  x1
        |  @param  y1
        |  @param  x2
        |  @param  y2
        |  @param  x3
        |  @param  y3
        |
        |  @return  point1
        |  @return  point2
        |  @return  point3
        *-------------------------------------------------------------------*/
    public Triangle(double x1, double y1, double x2, double y2, double x3, double y3)
    {
        point1 = new Point2D.Double(x1, y1);//(x1, y1) are the coordinates to create point1.
        point2 = new Point2D.Double(x2, y2);//(x2, y2) are the coordinates to create point2.
        point3 = new Point2D.Double(x3, y3);//(x3, y3) are the coordinates to create point3.
    }

    /*---------------------------- getSide1 ----------------------------
        |  Method getSide1()
        |
        |Purpose: Compute the length of the side of the triangle by using the
        |         Point2D class provided by the java library in the Appendix D
        |         (A17-18) in the text (Big Java: Early Objects, 5th Edition).
        |         Use method distance(double px, double py) from the Point2D class
        |         returns the distance from this Point2D to a specified Point2D.
        |
        |  @param  none
        |
        |  @return lengthOfSide1
        *-------------------------------------------------------------------*/
    public double getSide1()
    {
        double lengthOfSide1 = point1.distance(point2);

        return lengthOfSide1;
    }

    /*---------------------------- getSide2 ----------------------------
        |  Method getSide2()
        |
        |Purpose: Compute the length of the side of the triangle by using the
        |         Point2D class provided by the java library in the Appendix D
        |         (A17-18) in the text (Big Java: Early Objects, 5th Edition).
        |         Use method distance(double px, double py) from the Point2D class
        |         returns the distance from this Point2D to a specified Point2D.
        |
        |  @param  none
        |
        |  @return lengthOfSide2
        *-------------------------------------------------------------------*/
    public double getSide2()
    {
        double lengthOfSide2 = point2.distance(point3);

        return lengthOfSide2;
    }

    /*---------------------------- getSide3 ----------------------------
        |  Method getSide3()
        |
        |Purpose: Compute the length of the side of the triangle by using the
        |         Point2D class provided by the java library in the Appendix D
        |         (A17-18) in the text (Big Java: Early Objects, 5th Edition).
        |         Use method distance(double px, double py) from the Point2D class
        |         returns the distance from this Point2D to a specified Point2D.
        |
        |  @param  none
        |
        |  @return lengthOfSide3
        *-------------------------------------------------------------------*/
    public double getSide3()
    {
        final double lengthOfSide3 = point3.distance(point1);

        return lengthOfSide3;
    }

    /*---------------------------- getAngle1 ----------------------------
        |  Method getAngle1()
        |
        |Purpose: Computes the angle of a triangle by knowing the length of
        |         the three sides. If any side is 0 then the angles is 0. Otherwise,
        |         it will use the "angle" version of the Law of Cosines found in:
        |         https://www.mathsisfun.com/algebra/trig-solving-sss-triangles.html
        |
        |                 side1^2 + side3^2 - side2^2
        |  cos(angle1) = -----------------------------
        |                     2 * side1 * side3
        |
        | Where: angle1 is the one formed by the side1 and side3.
        |        side1 = lengthOfSide1
        |        side2 = lengthOfSide2
        |        side3 = lengthOfSide3
        |
        | For convenience and simplicity we will use:
        | NUMERATOR = side1^2 + side3^2 - side2^2
        |           = Math.pow(getSide1(), POW_OF_2) + Math.pow(getSide3(), POW_OF_2) - Math.pow(getSide2(), POW_OF_2)
        |
        | DENOMINATOR = 2 * side1 * side3
        |             = 2 * getSide1() * getSide3()
        |
        | Where: getSide1(), getSide2() and getSide3() are the length of each side.
        |
        | After that:
        |                 numerator
        |  cos(angle1) = ------------
        |                denominator
        |
        |   In order to compute the arc cosine, program will use Class java.lang.Math from Appendix D
        |   A-24, "acos" method. This method returns the angle IN RADIANS with the given cosine.
        |   Since the requested angle needs to be in DEGREES, we will also use from the same
        |   Class java.lang.Math the method toDegrees on A-26. This method converts radians to
        |   degrees returning the value in degrees.
        |   Therefore:
        |          angle1 = Math.toDegrees(Math.acos(numerator / denominator))
        |
        |  @param  none
        |
        |  @return angle1
        *-------------------------------------------------------------------*/
    public double getAngle1()
    {
        double angle1 = 0;//Hold values for angle1. Initial value is zero.

        if ((getSide1() == NO_LENGTH) || (getSide2() == NO_LENGTH) || (getSide3() == NO_LENGTH))
        {
            angle1 = 0;
        }
        else
        {
            double numerator = Math.pow(getSide1(), POW_OF_2) + Math.pow(getSide3(), POW_OF_2) - Math.pow(getSide2(), POW_OF_2);
            //Number 2 is not a magic number, previously documented in formula.
            double denominator = 2 * getSide1() * getSide3();
            angle1 = Math.toDegrees(Math.acos(numerator / denominator));
        }
        return angle1;
    }

    /*---------------------------- getAngle2 ----------------------------
        |  Method getAngle2()
        |
        |Purpose: Computes the angle of a triangle using the length of
        |         the three sides. If any side is 0 then the angles is 0. Otherwise,
        |         it will use the "angle" version of the Law of Cosines found in:
        |         https://www.mathsisfun.com/algebra/trig-solving-sss-triangles.html
        |
        |                 side1^2 + side2^2 - side3^2
        |  cos(angle2) = -----------------------------
        |                     2 * side1 * side2
        |
        | Where: angle1 is the one formed by the side1 and side2.
        |        side1 = lengthOfSide1
        |        side2 = lengthOfSide2
        |        side3 = lengthOfSide3
        |
        | For convenience and simplicity we will use:
        | NUMERATOR = side1^2 + side2^2 - side3^2
        |           = Math.pow(getSide1(), POW_OF_2) + Math.pow(getSide2(), POW_OF_2) - Math.pow(getSide3(), POW_OF_2)
        |
        | DENOMINATOR = 2 * side1 * side2
        |             = 2 * getSide1() * getSide2()
        |
        | Where: getSide1(), getSide2() and getSide3() are the length of each side.
        |
        | After that:
        |                 numerator
        |  cos(angle2) = ------------
        |                denominator
        |
        |   In order to compute the arc cosine, program will use Class java.lang.Math from Appendix D
        |   A-24, "acos" method. This method returns the angle IN RADIANS with the given cosine.
        |   Since the requested angle needs to be in DEGREES, we will also use from the same
        |   Class java.lang.Math the method toDegrees on A-26. This method converts radians to
        |   degrees returning the value in degrees.
        |   Therefore:
        |          angle2 = Math.toDegrees(Math.acos(numerator / denominator))
        |
        |  @param  none
        |
        |  @return angle2
        *-------------------------------------------------------------------*/
    public double getAngle2()
    {
        double angle2 = 0;//Hold values for angle1. Initial value is zero.

        if ((getSide1() == NO_LENGTH) || (getSide2() == NO_LENGTH) || (getSide3() == NO_LENGTH))
        {
            angle2 = 0;
        }
        else
        {
            double numerator = Math.pow(getSide1(), POW_OF_2) + Math.pow(getSide2(), POW_OF_2) - Math.pow(getSide3(), POW_OF_2);
            //Number 2 is not a magic number, previously documented in formula.
            double denominator = 2 * getSide1() * getSide2();
            angle2 = Math.toDegrees(Math.acos(numerator / denominator));
        }
        return angle2;
    }

    /*---------------------------- getAngle3 ----------------------------
        |  Method getAngle3()
        |
        |Purpose: Computes the angle of a triangle using the length of
        |         the three sides. If any side is 0 then the angles is 0. Otherwise,
        |         it will use the "angle" version of the Law of Cosines found in:
        |         https://www.mathsisfun.com/algebra/trig-solving-sss-triangles.html
        |
        |                 side2^2 + side3^2 - side1^2
        |  cos(angle3) = -----------------------------
        |                     2 * side2 * side3
        |
        | Where: angle1 is the one formed by the side2 and side3.
        |        side1 = lengthOfSide1
        |        side2 = lengthOfSide2
        |        side3 = lengthOfSide3
        |
        | For convenience and simplicity we will use:
        | NUMERATOR = side1^2 + side2^3 - side1^2
        |           = Math.pow(getSide2(), POW_OF_2) + Math.pow(getSide3(), POW_OF_2) - Math.pow(getSide1(), POW_OF_2)
        |
        | DENOMINATOR = 2 * side2 * side3
        |             = 2 * getSide2() * getSide3()
        |
        | Where: getSide1(), getSide2() and getSide3() are the length of each side.
        |
        | After that:
        |                 numerator
        |  cos(angle3) = ------------
        |                denominator
        |
        |   In order to compute the arc cosine, program will use Class java.lang.Math from Appendix D
        |   A-24, "acos" method. This method returns the angle IN RADIANS with the given cosine.
        |   Since the requested angle needs to be in DEGREES, we will also use from the same
        |   Class java.lang.Math the method toDegrees on A-26. This method converts radians to
        |   degrees returning the value in degrees.
        |   Therefore:
        |          angle3 = Math.toDegrees(Math.acos(numerator / denominator))
        |
        |  @param  none
        |
        |  @return angle3
        *-------------------------------------------------------------------*/
    public double getAngle3()
    {
        double angle3 = 0;//Hold values for angle3

        if ((getSide1() == NO_LENGTH) || (getSide2() == NO_LENGTH) || (getSide3() == NO_LENGTH))
        {
            angle3 = 0;
        }
        else
        {
            double numerator = Math.pow(getSide2(), POW_OF_2) + Math.pow(getSide3(), POW_OF_2) - Math.pow(getSide1(), POW_OF_2);
            //Number 2 is not a magic number, previously documented in formula.
            double denominator = 2 * getSide2() * getSide3();
            angle3 = Math.toDegrees(Math.acos(numerator / denominator));
        }
        return angle3;
    }

    /*---------------------------- getPerimeter ----------------------------
        |  Method getPerimeter()
        |
        |Purpose: Computes the perimeter of the triangle using the length of
        |         the three sides. In order to do so, program will use the
        |         getSide1(), getSide2() and getSide3(), These methods return
        |         the length of each side.
        |         Using the following formula:
        |
        |   perimeterOfTriangle = getSide1() + getSide2() + getSide3()
        |
        |  @param  none
        |
        |  @return perimeterOfTriangle
        *-------------------------------------------------------------------*/
    public double getPerimeter()
    {
        double perimeterOfTriangle = getSide1() + getSide2() + getSide3();
        return perimeterOfTriangle;
    }

    /*---------------------------- getArea ----------------------------
        |  Method getArea()
        |
        |Purpose: Computes the area of the triangle using the perimeter.
        |         Program uses Heron's Formula from:
        |         http://www.softschools.com/math/geometry/topics/area_of_a_triangle_part_2/
        |         Also it will use Math.sqr from Class java.lang.Math from Appendix D.
        |
        |         Area = √(s(s-side1)(s-side2)(s-side3)
        |
        | where: Area = areaOfTriangle
        |        side1 = lengthOfSide1
        |        side2 = lengthOfSide2
        |        side3 = lengthOfSide3
        |
        |             side1 + side2 + side3
        |        s =  ---------------------
        |                       2
        |
        | For convenience and simplicity we will use:
        | halfPerimeter = getPerimeter() / 2
        | contentOfEquation = (halfPerimeter - getSide1()) * (halfPerimeter - getSide2()) * (halfPerimeter - getSide3())
        | areaOfTriangle = Math.sqrt(halfPerimeter * contentOfEquation)
        |
        |  @param  none
        |
        |  @return areaOfTriangle
        *-------------------------------------------------------------------*/
    public double getArea()
    {
        //Number 2 is not a magic number, previously documented in formula.
        double halfPerimeter = getPerimeter() / 2;
        double contentOfEquation = (halfPerimeter - getSide1()) * (halfPerimeter - getSide2()) * (halfPerimeter - getSide3());
        double areaOfTriangle = Math.sqrt(halfPerimeter * contentOfEquation);

        return areaOfTriangle;
    }

    /*---------------------------- testEquilateral ----------------------------
        |  Method testEquilateral()
        |
        |Purpose: It test if the triangle is equilateral, first it checks if the
        |         length of any side is different than 0. In case the difference is 0,
        |         then it will set the condition to false and the triangle is not
        |         equilateral. Then it compares the absolute value of the difference
        |         between all the sides against a small threshold set to 4 decimal places.
        |         Also it will use Math.abs from Class java.lang.Math from Appendix D.
        |         Using following formula.
        |
        | Math.abs(getSide1() - getSide2() - getSide3()) < Math.pow(BASE_10, THRESHOLD_ACCURACY
        |
        |  @param  none
        |
        |  @return equilateralTriangle
        *-------------------------------------------------------------------*/
    public boolean testEquilateral()
    {
        boolean equilateralTriangle = false;

        if ((getSide1() == NO_LENGTH) || (getSide2() == NO_LENGTH) || (getSide3() == NO_LENGTH))
        {
            equilateralTriangle = false;
        }
        else if (Math.abs(getSide1() - getSide2() - getSide3()) < THRESHOLD_CONDITION)
        {
            equilateralTriangle = true;
        }
        else
        {
            equilateralTriangle = false;
        }
        return equilateralTriangle;
    }

    /*---------------------------- rightAngled ----------------------------
        |  Method rightAngled()
        |
        |Purpose: It test if the triangle is right angled by comparing the
        |         absolute value of the difference between each side an 90,
                  against a small threshold set to 4 decimal places.
        |         Also it will use Math.abs from Class java.lang.Math from Appendix D.
        |         Using following formula.
        |
        | (Math.abs(getAngle1() - NINETY_DEGREES) <= THRESHOLD_CONDITION)
        |       || (Math.abs(getAngle2() - NINETY_DEGREES) <= THRESHOLD_CONDITION)
        |       || (Math.abs(getAngle3() - NINETY_DEGREES) <= THRESHOLD_CONDITION)
        |
        |  @param  none
        |
        |  @return rightAngledTriangle
        *-------------------------------------------------------------------*/
    public boolean rightAngled()
    {
        boolean rightAngledTriangle;

        if ((Math.abs(getAngle1() - NINETY_DEGREES) <= THRESHOLD_CONDITION)
                || (Math.abs(getAngle2() - NINETY_DEGREES) <= THRESHOLD_CONDITION)
                || (Math.abs(getAngle3() - NINETY_DEGREES) <= THRESHOLD_CONDITION))
        {
            rightAngledTriangle = true;
        } else
        {
            rightAngledTriangle = false;
        }
        return rightAngledTriangle;
    }

}

