﻿/*=============================================================================
|   Source code: TriangleTester.java
|        Author: Yonal Hernandez
|    Student ID: 6178656
|    Assignment: Program #2 Triangle
|
|        Course: COP3337 Computer Programing II
|       Section: U02
|    Instructor: William Feild
|      Due Date: February 07, 2019 at the beginning of class
|
|	I hereby certify that this collective work is my own
|	and none of it is the work of any other person or entity.
|	_______Yonal Hernandez__________________________________
|
|      Language: Java
|   Compile/Run: Compile and run
| 	       javac TriangleTester.java  Triangle.java
|	       java  TriangleTester
|
|  +-----------------------------------------------------------------------------
|
|  Description: Program will accept and validate six real numbers entered by user,
|               those numbers will be interpreted as coordinates of three points
|               forming a triangle. Therefore, it will provide the length of each
|               side, value of every angle, perimeter and area of the triangle
|               as it will say if it is a equilateral or right angled. In order to
|               do so, two different classes will be used, a TriangleTester class
|               will handled the input/validation and output of data, while a
|               Triangle class will compute all the calculations with the help of
|               the Point2D class provided by the java library in the Appendix D (A17-18)
|               in the text (Big Java: Early Objects, 5th Edition)
|
|        Input: Program will prompt a user to provide x- and y-coordinates for the
|               three Points of a triangle. User input must be validated. User
|               prompts must clearly indicate how to enter values for each Point
|               (which is: a pair of x- and y-coordinates, separated by a <return>).
|               A coordinate is a floating-point value and can be positive, negative
|               or zero.
|
|       Output: Output will include all three Points, the lengths of all three sides,
|               the three angles at the corners, the perimeter and the area of the
|               triangle, and whether the triangle is Equilateral or Right-angled or
|               neither — all in a nicely formatted layout, as directed. Values
|               displayed will be labeled and designated in the appropriate “units”,
|               angles will be displayed in “degrees”. All printed values will be
|               rounded and formatted to four decimal-point accuracy, degrees rounded
|               to the nearest degree.
|
|      Process: 1. User will be prompt to enter 6 real numbers.
|               2. Program validate numbers protecting against non-numerical characters.
                   It will inform of invalid input and request a valid real number.
|               3. Entered numbers interpreted as coordinates are saved and send to
|                  Triangle class constructor.
|               4. With the help of the Point class coordinates are transform to points.
|               5. Program computes length of the sides, angles, perimeter and area of
|                  the triangle formed by the 6 coordinates.
|               6. Two different utility methods check to see if the triangle is
|                  equilateral or right angled.
|               7. Results will be rounded and formatted to four decimal-point accuracy,
|                  degrees rounded to the nearest degree.
|
|
|   Required Features Not Included:  None.
|
|   Known Bugs: 1. Do not work with numbers with size over 8 bytes.
|               2. Some cases values for angles are 0. This happens when they are so small,
|                  almost 0 and since the output for angles do not include decimal places.
|                  They are round to 0.
|  *===========================================================================*/

import java.util.Scanner;//Prompt and read input from user.

public class TriangleTester
{
    public static void main(String[] args)
    {
        boolean validRealNumber = false;//Checks if the coordinate is a valid number.
        double coordinateValue = 0;//Hold values for input coordinates inside validate input method.

        Scanner userInput = new Scanner(System.in);//Prompt and read info from user.

        showPurpose();

        //Repeated 6 times because it returns a different coordinate each time.
        double x1 = validateInput(userInput, validRealNumber, coordinateValue);
        double y1 = validateInput(userInput, validRealNumber, coordinateValue);
        double x2 = validateInput(userInput, validRealNumber, coordinateValue);
        double y2 = validateInput(userInput, validRealNumber, coordinateValue);
        double x3 = validateInput(userInput, validRealNumber, coordinateValue);
        double y3 = validateInput(userInput, validRealNumber, coordinateValue);

        //Allows you to use methods from Triangle class passing these parameters to his constructor.
        Triangle triangle = new Triangle(x1, y1, x2, y2, x3, y3);

        showResults(x1, y1, x2, y2, x3, y3, triangle);
    }

    /*---------------------------- showPurpose ----------------------------
        |  Method showPurpose()
        |
        |  Purpose: Display program purpose
        |
        |  @param  none
        |
        |  @return none
        *-------------------------------------------------------------------*/
    public static void showPurpose()
    {
        System.out.println("Enter the x,y coordinates of three points in the following order (x1, y1) (x2, y2) (x3, y3).");
        System.out.println("Separate each coordinate with a <return>");
    }

    /*---------------------------- validateInput ----------------------------
        |  Method validateInput(Scanner userInput, boolean validRealNumber, double coordinateValue)
        |
        |  Purpose: Protects program from non-numerical values, detecting and
        |           saving only real numbers. It alerts user if input is not valid.
        |           Returning the value of each coordinate.
        |
        |  @param  userInput
        |  @param  validRealNumber
        |  @param  coordinateValue
        |
        |  @return  coordinateValue
        *-------------------------------------------------------------------*/
    private static double validateInput(Scanner userInput, boolean validRealNumber, double coordinateValue)
    {
        do
        {
            userInput.hasNextDouble();

            if (userInput.hasNextDouble())
            {
                coordinateValue = userInput.nextDouble();
                validRealNumber = true;
            }
            else
            {
                System.out.println("That is not a numerical value!!!. Please enter a real number.");
                //Dispose non-numerical value.
                userInput.next();
            }
        }
        while (!validRealNumber);

        return coordinateValue;
    }

    /*---------------------------- showResults ----------------------------
        |  Method showResults(double x1, double y1, double x2, double y2, double x3, double y3, Triangle triangle)
        |
        |  Purpose: Display result of computations. Using printf, it
        |           specify how values are formatted in decimal places.
        |
        |  @param  x1
        |  @param  y1
        |  @param  x2
        |  @param  y2
        |  @param  x3
        |  @param  y3
        |  @param  triangle
        |
        |  @return  none
        *-------------------------------------------------------------------*/
    public static void showResults(double x1, double y1, double x2, double y2, double x3, double y3, Triangle triangle)
    {
        final String UNITS = " units";//Useful for future changes.
        final String DEGREES = " degrees";//Useful for future changes.
        final String SQUARE_UNITS = " square units";//Useful for future changes.

        System.out.printf("Point 1 coordinates: (%.4f, %.4f)", x1, y1);
        System.out.printf("\nPoint 2 coordinates: (%.4f, %.4f)", x2, y2);
        System.out.printf("\nPoint 3 coordinates: (%.4f, %.4f)", x3, y3);
        System.out.printf("\nSide 1 length: %.4f" + UNITS, triangle.getSide1());
        System.out.printf("\nSide 2 length: %.4f" + UNITS, triangle.getSide2());
        System.out.printf("\nSide 3 length: %.4f" + UNITS, triangle.getSide3());
        System.out.printf("\nAngle 1: %.0f" + DEGREES, triangle.getAngle1());
        System.out.printf("\nAngle 2: %.0f" + DEGREES, triangle.getAngle2());
        System.out.printf("\nAngle 3: %.0f" + DEGREES, triangle.getAngle3());
        System.out.printf("\nThe perimeter of the triangle is %.4f" + UNITS, triangle.getPerimeter());
        System.out.printf("\nThe area of the triangle is %.4f" + SQUARE_UNITS, triangle.getArea());
        System.out.println("\nThe triangle is Equilateral?: " + triangle.testEquilateral());
        System.out.println("The triangle is Right-angled?: " + triangle.rightAngled());
    }
}
