/*=======================================================================
|     Source code: LastDigitDistribution.java
|           Class: LastDigitDistribution
|          Author: Yonal Hernandez
|      Student ID: 6178656
|      Assignment: Program #5 Sequence of Primes
|
|          Course: COP3337 Computer Programing II
|         Section: U02
|      Instructor: William Feild
|        Due Date: March 26, 2019 at the beginning of class
|
|	I hereby certify that this collective work is my own
|	and none of it is the work of any other person or entity.
|	_______Yonal Hernandez__________________________________
|
|        Language: Java
|     Compile/Run: Compile
| 	         javac LastDigitDistribution.java
|
|         Purpose: Auxiliary class for Sequence Demo. Providing an analysis
|                  of the last digit distribution of the primes numbers found.
|                  This class analyzes the distribution of the last digit of values
|                  from a sequence.
|                  Uses worked example 1 from chapter 10 with some modifications.
|                  please refer to: wiley.com/go/javaexamples
|
|   Inherits From: None
|
|      Interfaces: None
|
|  +-----------------------------------------------------------------------
|
|       Constants:
|         public static final int AMOUNT_OF_NUMBERS = 10;
|            Amount of digits [0-9].
|
| +-----------------------------------------------------------------------
|
|    Constructors:
|         public LastDigitDistribution()
|           Constructs a distribution whose counters are set to zero.
|           And size of array is set to desired amount of primes.
|
|   Class Methods: None.
|
|Instance Methods:
|       public void setLastDigit(int[] primes)
|           return None
|
|       public int[] getDigitCounterStore()
|           return digitCounterStore;
|
|  *===========================================================================*/
public class LastDigitDistribution
{
    public static final int AMOUNT_OF_NUMBERS = 10;

    private int primeNumber = PrimeSequence.NO_VALUE;
    private int lastDigit = PrimeSequence.NO_VALUE;
    private int[] digitCounterStore;

    /*---------------------------- LastDigitDistribution ----------------------------
         |  Method LastDigitDistribution()
         |
         |Purpose: Default constructor for LastDigitDistribution class.
         |         Constructs a distribution whose counters are set to zero.
         |         And size of array is set to desired amount of primes.
         |
         |  @param None
         |
         | @return None
         *-------------------------------------------------------------------*/
    public LastDigitDistribution()
    {
        digitCounterStore = new int[AMOUNT_OF_NUMBERS];
    }

    /*---------------------------- setLastDigit ----------------------------
         |  Method setLastDigit(int[] primes)
         |
         |Purpose: Processes values from this sequence of primes numbers determining
         |         how many times last digit repeats.
         |
         |  @param primes
         |
         | @return None
         *-------------------------------------------------------------------*/
    public void setLastDigit(int[] primes)
    {
        for (int primesCounter = PrimeSequence.NO_VALUE; primesCounter < primes.length; primesCounter++)
        {
            primeNumber = primes[primesCounter];
            lastDigit = primeNumber % AMOUNT_OF_NUMBERS;
            digitCounterStore[lastDigit]++;
        }
    }

    /*---------------------------- getDigitCounterStore ----------------------------
         |  Method getDigitCounterStore()
         |
         |Purpose: Returns array of last digit distribution stored.
         |
         |  @param primes
         |
         | @return digitCounterStore
         *-------------------------------------------------------------------*/
    public int[] getDigitCounterStore()
    {
        return digitCounterStore;
    }
}

