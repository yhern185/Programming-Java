/*=======================================================================
|     Source code: PrimeSequence.java
|           Class: PrimeSequence
|          Author: Yonal Hernandez
|      Student ID: 6178656
|      Assignment: Program #5 Sequence of Primes
|
|          Course: COP3337 Computer Programing II
|         Section: U02
|      Instructor: William Feild
|        Due Date: March 26, 2019 at the beginning of class
|
|	I hereby certify that this collective work is my own
|	and none of it is the work of any other person or entity.
|	_______Yonal Hernandez__________________________________
|
|        Language: Java
|     Compile/Run: Compile
| 	         javac PrimeSequence.java
|
|         Purpose: Find and returns a desired numbers of primes excluding
|                  starting number. Uses modified example from:
|                  https://www.baeldung.com/java-generate-prime-numbers
|                  Implements Sequence Interface and its next() method.
|
|   Inherits From: None
|
|      Interfaces: Sequence.java
|
|  +-----------------------------------------------------------------------
|
|       Constants:
|   public static final int EXCLUDE_FIRST_NUMBER = 1;
|       To exclude start number (per requirements)
|
|   public static final int NO_VALUE = 0;
|       To easily use for comparison or start point on counters.
|
|   public static final int AVOID_EVEN = 2;
|       Avoid even numbers finding primes.
|
|   public static final int FIRST_PRIME = 2;
|       First prime;
|
| +-----------------------------------------------------------------------
|
|    Constructors:
|         public PrimeSequence(int testNumber, int amountOfPrimes)
|           Setup values for initial test number and amount of primes to be found.
|
|   Class Methods:
|        private void incrementTestNumber()
|           Increment numbers to be tested as primes avoiding even numbers making
|           program much more efficient.
|
|        public boolean isPrime()
|           return boolean (true or false);
|
|Instance Methods:
|       public int next()
|           return  nextPrime;
|
|       public int[] getPrimes()
|           return storedPrimes;
|
|  *===========================================================================*/

public class PrimeSequence implements Sequence
{
    public static final int EXCLUDE_FIRST_NUMBER = 1;
    public static final int NO_VALUE = 0;
    public static final int AVOID_EVEN = 2;
    public static final int FIRST_PRIME = 2;

    private int nextPrime = NO_VALUE;
    private int testNumber = NO_VALUE;
    private int amountOfPrimes = NO_VALUE;
    private int primesCounter = NO_VALUE;


    /*---------------------------- PrimeSequence ----------------------------
         |  Method PrimeSequence(int testNumber, int amountOfPrimes)
         |
         |Purpose: Constructor for PrimeSequence class. Setup initial values
         |         for start number and amount of primes starting by the
         |         number after the first one (excluding it).
         |
         |  @param None
         |
         | @return None
         *-------------------------------------------------------------------*/
    public PrimeSequence(int testNumber, int amountOfPrimes)
    {
        this.testNumber = testNumber;
        this.amountOfPrimes = amountOfPrimes;
    }

    /*---------------------------- next ----------------------------
         |  Method next()
         |
         |Purpose: Implemented method from sequence interface. It provides the
         |         next prime number. Uses isPrime() to determine if a number
         |         is prime or not.
         |
         |  @param None
         |
         | @return nextPrime
         *-------------------------------------------------------------------*/
    public int next()
    {
        if (testNumber != FIRST_PRIME)
        {
            while(!isPrime())
            {
                testNumber++;
            }
        }
        else
        {
            nextPrime = FIRST_PRIME;
        }
        nextPrime = testNumber;
        return  nextPrime;
    }

    /*---------------------------- isPrime ----------------------------
         |  Method isPrime()
         |
         |Purpose: Checks a number to determine if it is prime or not. In
         |         positive cases return true, otherwise returns false.
         |         Uses a modified method from:
         |         https://www.baeldung.com/java-generate-prime-numbers
         |         Use Math.sqrt narrow test numbers as much as possible
         |         instead of elevate the counter to the power of 2 making
         |         our search much more efficient.
         |
         |  @param None
         |
         | @return boolean (true or false);
         *-------------------------------------------------------------------*/
    private boolean isPrime()
    {
        for(int counter = FIRST_PRIME; (counter <= Math.sqrt(testNumber)); counter++)
        {
            if(testNumber % counter == NO_VALUE)
            {
                return false;
            }
        }
        return true;
    }

    /*---------------------------- getPrimes ----------------------------
         |  Method getPrimes()
         |
         |Purpose: Saved primes numbers into an array of a length determine by
         |         the amount of primes to be found. If integer numbers reach its
         |         limits it protects against overflow saving 0 in the array
         |         until it is finished.
         |
         |  @param None
         |
         | @return storedPrimes;
         *-------------------------------------------------------------------*/
    public int[] getPrimes()
    {
        int[] storedPrimes = new int[amountOfPrimes];
        for(primesCounter = NO_VALUE; primesCounter < storedPrimes.length; primesCounter++)
        {
            if(next() > NO_VALUE)
            {
                storedPrimes[primesCounter] = next();
                incrementTestNumber();
            }
            else
            {
                storedPrimes[primesCounter] = NO_VALUE;
            }
        }
        return storedPrimes;
    }

    /*---------------------------- incrementTestNumber ----------------------------
         |  Method incrementTestNumber()
         |
         |Purpose: Increment numbers to be tested as primes avoiding even numbers
         |         making program much more efficient. If test number is
         |         FIRST_PRIME then it will increment by one only.
         |
         |  @param None
         |
         | @return None
         *-------------------------------------------------------------------*/
    private void incrementTestNumber()
    {
        if(testNumber != FIRST_PRIME)
        {
            testNumber += AVOID_EVEN;
        }
        else
        {
            testNumber++;
        }
    }
}
