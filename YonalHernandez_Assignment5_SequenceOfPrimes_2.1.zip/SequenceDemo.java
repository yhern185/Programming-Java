/*=============================================================================
|   Source code: SequenceDemo.java
|        Author: Yonal Hernandez
|    Student ID: 6178656
|    Assignment: Program #5 Sequence of Primes
|
|        Course: COP3337 Computer Programing II
|       Section: U02
|    Instructor: William Feild
|      Due Date: March 26, 2019 at the beginning of class
|
|	I hereby certify that this collective work is my own
|	and none of it is the work of any other person or entity.
|	_______Yonal Hernandez__________________________________
|
|      Language: Java
|   Compile/Run: Compile and run
|   *Presence of Sequence.java Interface in the same directory is required.
|   *Two positive integers greater than 0 need to be passed as arguments in the
|    command-line at run time. ex: INTEGER_1 INTEGER_2
| 	       javac SequenceDemo.java  PrimeSequence.java  LastDigitDistribution.java
|	       java  SequenceDemo INTEGER_1 INTEGER_2
|
|  +-----------------------------------------------------------------------------
|
|  Description: Create a class PrimeSequence that implements the Sequence interface
|               and the next() method. Provide a Demo program that will produce an
|               arbitrary sequence of n prime numbers in table format and will
|               perform an analysis of those n prime numbers. Reference to the
|               Worked Example 10.1 (page 473 in the text - go to
|               wiley.com/go/javaexamples for sample downloads) could be useful.
|               Program protects against integer overflow displaying them as 0
|               in the table.
|
|        Input: Input will be provided on the command-line. Two input constants
|               will be placed on the command-line upon execution, no other user
|               input permitted. The prime sequence will start with the next prime
|               after the first number, and the second number is the number of prime
|               numbers to be sequenced. Both numbers must be integers and both
|               numbers must be 1 or greater. Command-line input is
|               validated. If either input fails validation, program
|               display why the input failed, and it gracefully terminate.
|
|       Output: Output will provide a table of desired amount of prime numbers.
|               The table will be as close to “square” as possible with at most 10
|               entries per row. More than 100 entries will have 10 columns and will
|               not be squarish. All table entries will be right-aligned.
|               Additionally, output will include a “histogram” for the occurrences
|               of the last digit [0-9] for each prime number. The histogram will be
|               horizontal (not vertical) and will be scaled (as a percentage %),
|               with a legend at the bottom to explain the scale and display the
|               total count of primes. Each digit’s entry (a sequence of *’s) must
|               fit on a single row, and it must be properly labeled (actual count,
|               scaled %) and aligned. Scale will need to be flexible. Round up
|               fraction percentages.
|
|      Process:
|               1. Accept and validate input from command-line.
|                   > There are two arguments as input.
|                   > Both arguments are positive integer numbers greater than 0.
|               2. Save argument 1 as first number after what we must find primes.
|               3. Save argument 2 as amount of primes to be found.
|                  *Both arguments are saved using method valueOf(), which returns
|                   an Integer object holding the value of the specified String.
|                   Please refer to:
|                   https://docs.oracle.com/javase/7/docs/api/java/lang/Integer.html
|               4. Create objects from auxiliary classes and get an array with
|                  requested primes.
|               5. Display table for primes (as square of possible up to 10
|                  columns).
|               6. Display histogram with stars and percents amount round of based
|                  on different cases.
|                   > Where amount of primes is greater than a fixed number, every
|                     star correspond with a % 1 to 1.
|                   > Where amount of primes is less than a fixed number, every star
|                     represent a 1 to 1 last digit occurrence.
|                     *Fixed number for this example have been set to
|                      MIN_AMOUNT_OF_PRIMES.
|                   > Histogram display 0 occurrences when programs protects itself
|                     against integer overflow.
|
|
|
|   Required Features Not Included: Requirements ask to represent stars in histogram
|                                   as some scale of percent, however, I have decide
|                                   to represent stars as a 1 to 1 reference of the
|                                   last digit occurrence in cases where the desired
|                                   number of primes is less than a fixed number set
|                                   to MIN_AMOUNT_OF_PRIMES for this example.
|                                   Decision was made due to cosmetic preferences.
|
|   Known Bugs: OutOfMemoryError when trying to find a super big amount of primes.
|               Problem varies from computer to computer at run-time, for the case
|               of my laptop it is about MAX_AMOUNT_OF_PRIMES_ALLOWED. That is why
|               when program validates input, it will gracefully terminate if it
|               founds that number as amount of primes required.
|  *===========================================================================*/

import java.lang.Math;//Allows the use of the Math class.
import java.util.Scanner;//Allow us to check information as input.

public class SequenceDemo
{
    public static final int MAX_NUMBER_OF_COLUMNS = 10;
    public static final int MAX_PRIMES_TO_DISPLAY = 100;
    public static final int MAX_SPACE_FOR_STARS = 40;
    public static final int MIN_SPACE_FOR_STARS = 5;
    public static final int MIN_AMOUNT_OF_PRIMES = 4;
    public static final int STRING_LENGTH_FOR_VALIDATION = 2;
    public static final int INDEX_1 = 1;
    public static final int MAX_AMOUNT_OF_PRIMES_ALLOWED = 1064669898;
    public static final double FULL_PERCENTAGE = 100.00;
    public static final String PERCENTAGE_SIGN = "%.";
    public static final String LAST_DIGIT_OCCURRENCE = " last digit occurrence.";
    public static final String ONE2ONE = " 1";

    public static void main(String[] args)
    {
        commandLineValidation(args);
        final int START_NUMBER = Integer.valueOf(args[PrimeSequence.NO_VALUE]) +
                PrimeSequence.EXCLUDE_FIRST_NUMBER;
        final int AMOUNT_OF_PRIMES = Integer.valueOf(args[INDEX_1]);

        PrimeSequence primeSequence = new PrimeSequence(START_NUMBER,
                AMOUNT_OF_PRIMES);
        LastDigitDistribution lastDigitDistribution = new LastDigitDistribution();
        int[] primes = primeSequence.getPrimes();

        displayTableOfPrimes(AMOUNT_OF_PRIMES, primes, START_NUMBER);
        displayHistogram(lastDigitDistribution, primes, AMOUNT_OF_PRIMES);
    }

    /*---------------------- commandLineValidation ----------------------------
         |  Method commandLineValidation(String[] args)
         |
         |Purpose: Validation method needed to check arguments passed (if any)
         |         in the command-line.
         |         Uses ExceptionDemo.java from Chapter 11, section 4 as a guide,
         |         please refer to:
         |         http://wiley.com/go/javaexamples
         |
         |  @param args
         |
         | @return None
         *-------------------------------------------------------------------*/
    private static void commandLineValidation(String[] args)
    {
        checkForTwoArguments(args);
        checkForPositiveIntegers(args);
        avoidOutOfMemoryError(args);
    }

    /*---------------------- avoidOutOfMemoryError ----------------------------
         |  Method avoidOutOfMemoryError(String[] args)
         |
         |Purpose: Validate argument 2 to see if it is less than
         |         MAX_AMOUNT_OF_PRIMES_ALLOWED, preventing our program to crash
         |         due to the lack of memory caused by the excessive amount of
         |         prime numbers required. If pass conditions program will
         |         continue, otherwise program display why the input failed,
         |         and it gracefully terminate.
         |         Problem varies from computer to computer at run-time, for the
         |         case of my laptop it is about MAX_AMOUNT_OF_PRIMES_ALLOWED.
         |         Please refer to:
         |         https://docs.oracle.com/javase/6/docs/api/
         |
         |  @param args
         |
         | @return None
         *-------------------------------------------------------------------*/
    private static void avoidOutOfMemoryError(String[] args)
    {
        String argument = args[INDEX_1];
        Scanner commandLineInput = new Scanner(argument);
        int amountOfPrimes = commandLineInput.nextInt();
        if(amountOfPrimes > MAX_AMOUNT_OF_PRIMES_ALLOWED)
        {
            System.out.println("Argument 2 is greater than: " + MAX_AMOUNT_OF_PRIMES_ALLOWED);
            System.out.println("Two Positive Integers greater than " + PrimeSequence.NO_VALUE +
                    " separated by a space need to be passed in the command-line");
            System.out.println("Argument 2: Amount of Primes, needs to be less than: "
                    + MAX_AMOUNT_OF_PRIMES_ALLOWED);
            System.exit(1);
        }

    }

    /*---------------------- checkForPositiveIntegers ----------------------------
         |  Method checkForPositiveIntegers(String[] args)
         |
         |Purpose: Validate arguments to see if they are positive integers numbers
         |         greater than 0. If pass conditions, program will continue,
         |         otherwise program display why the input failed, and it
         |         gracefully terminate.
         |
         |  @param args
         |
         | @return None
         *-------------------------------------------------------------------*/
    private static void checkForPositiveIntegers(String[] args)
    {
        String argument1 = args[PrimeSequence.NO_VALUE];
        String argument2 = args[INDEX_1];
        Scanner commandLineInput1 = new Scanner(argument1);
        Scanner commandLineInput2 = new Scanner(argument2);

        if(!(commandLineInput1.hasNextInt()) || !(commandLineInput2.hasNextInt()))
        {
            System.out.println("Arguments are not Integers");
            System.out.println("Two Positive Integers greater than "
                    + PrimeSequence.NO_VALUE + " separated by a space need to " +
                    "be passed in the command-line");
            System.out.println("Argument 2: Amount of Primes, needs to be less than: "
            + MAX_AMOUNT_OF_PRIMES_ALLOWED);
            System.exit(1);
        }
        else
        {
            int startNumber = commandLineInput1.nextInt();
            int amountOfPrimes = commandLineInput2.nextInt();
            if((startNumber <= PrimeSequence.NO_VALUE) || (amountOfPrimes <=
                    PrimeSequence.NO_VALUE))
            {
                System.out.println("Arguments are not greater than " + PrimeSequence.NO_VALUE);
                System.out.println("Two Positive Integers greater than " + PrimeSequence.NO_VALUE +
                        " separated by a space need to be passed in the command-line");
                System.out.println("Argument 2: Amount of Primes, needs to be less than: "
                        + MAX_AMOUNT_OF_PRIMES_ALLOWED);
                System.exit(1);
            }
        }
    }

    /*---------------------- checkForTwoArguments ----------------------------
         |  Method checkForTwoArguments(String[] args)
         |
         |Purpose: Validate arguments to see if they are two arguments passed
         |         in the command-line. If pass conditions, programs will continue,
         |         otherwise program display why the input failed, and it
         |         gracefully terminate.
         |
         |  @param args
         |
         | @return None
         *-------------------------------------------------------------------*/
    private static void checkForTwoArguments(String[] args)
    {
        if(args.length != STRING_LENGTH_FOR_VALIDATION)
        {
            System.out.println("No enough arguments in the command line.");
            System.out.println("Two Positive Integers greater than " + PrimeSequence.NO_VALUE +
                    " separated by a space need to be passed in the command-line");
            System.out.println("Argument 2: Amount of Primes, needs to be less than: "
                    + MAX_AMOUNT_OF_PRIMES_ALLOWED);
            System.exit(1);
        }
    }

    /*---------------------- displayHistogram ----------------------------
         |  Method displayHistogram(LastDigitDistribution lastDigitDistribution,
                                         int[] primes, int amountOfPrimes)
         |
         |Purpose: Display a histogram based on a analysis made on the results
         |         obtained with the desired obtained prime numbers.
         |
         |  @param lastDigitDistribution
         |  @param primes
         |  @param amountOfPrimes
         |
         | @return None
         *-------------------------------------------------------------------*/
    private static void displayHistogram(LastDigitDistribution lastDigitDistribution,
                                         int[] primes, int amountOfPrimes)
    {
        lastDigitDistribution.setLastDigit(primes);
        int[] digitCounterStore = lastDigitDistribution.getDigitCounterStore();
        int[] percentage = new int[digitCounterStore.length];
        findPercentages(percentage, digitCounterStore, amountOfPrimes);

        System.out.println("\nLast Digit Histogram:");
        System.out.println("Scaled as %, each * = " + determineLabel(amountOfPrimes, percentage));
        System.out.println("Total count may vary slightly from 100% due to rounding percentages\n");
        for (int digitCounter = PrimeSequence.NO_VALUE; digitCounter < digitCounterStore.length;
             digitCounter++)
        {
            System.out.printf("[%d]", digitCounter);
            displayStars(percentage, amountOfPrimes, digitCounterStore, digitCounter);
            System.out.printf("%s%2d%s %3d%s) %n", "(", digitCounterStore[digitCounter], ",",
                    percentage[digitCounter] , "%");
        }
        if(amountOfPrimes > MIN_AMOUNT_OF_PRIMES)
        {
            displayTotalForLargeNumberOfPrimes(amountOfPrimes, percentage);
        }
        else
        {
            displayTotalForSmallNumberOfPrimes(amountOfPrimes, percentage);
        }
        System.out.println("+Histogram entries in (0) row indicate overflow results");
    }

    /*---------------------- findPercentages ----------------------------
         |  Method findPercentages(int[] percentage, int[] digitCounterStore,
                                        int amountOfPrimes)
         |
         |Purpose: Save percentages values into array int[] percentage to be
         |         used in the histogram. Uses method getPercentage() to do so.
         |
         |  @param percentage
         |  @param digitCounterStore
         |  @param amountOfPrimes
         |
         | @return None
         *-------------------------------------------------------------------*/
    private static void findPercentages(int[] percentage, int[] digitCounterStore,
                                        int amountOfPrimes)
    {
        for (int digitCounter = PrimeSequence.NO_VALUE; digitCounter < digitCounterStore.length;
             digitCounter++)
        {
            percentage[digitCounter] = getPercentage(digitCounterStore[digitCounter],
                    amountOfPrimes);
        }

    }

    /*---------------------- determineLabel ----------------------------
         |  Method determineLabel(int amountOfPrimes)
         |
         |Purpose: Determine with sign to use to match stars on the histogram.
         |         If amount of primes is less than a fixed number (in this case
         |         MIN_AMOUNT_OF_PRIMES) will match stars 1 to 1 with the last
         |         digit occurrence, otherwise will match stars 1 to 1 with the
         |         percentage of the last digit occurrence if. In the special
         |         overflow cases with a percentage greater than
         |         MAX_SPACE_FOR_STARS will not be an exact correspondence with stars
         |         and percent, therefore, all whitespace will be filled with
         |         stars showing and overwhelming presence of them.
         |
         |  @param amountOfPrimes
         |
         | @return basedOnAmountOfPrimes
         *-------------------------------------------------------------------*/
    private static String determineLabel(int amountOfPrimes, int[] percentage)
    {
        String label = ONE2ONE + PERCENTAGE_SIGN;

        if(amountOfPrimes <= MIN_AMOUNT_OF_PRIMES)
        {
            label = ONE2ONE + LAST_DIGIT_OCCURRENCE;
        }
        else if(percentage[PrimeSequence.NO_VALUE] > MAX_SPACE_FOR_STARS)
        {
            label = ONE2ONE + PERCENTAGE_SIGN + specialOverflowCases();
        }

        return  label;
    }

    /*---------------------- specialOverflowCases ----------------------------
         |  Method specialOverflowCases()
         |
         |Purpose: Prints an specified String for overflow cases with a percentage
         |         greater than MAX_SPACE_FOR_STARS. It will not be an exact
         |         correspondence with stars and percent, therefore, all whitespace
         |         will be filled with stars showing and overwhelming presence of
         |         them.
         |
         |  @param amountOfPrimes
         |
         | @return basedOnAmountOfPrimes
         *-------------------------------------------------------------------*/
    private static String specialOverflowCases()
    {
        String specialCases = "\nExcept for overflow cases [0]. " +
                "Non-exact one to one correspondence is made." +
                "\n\"For " + "overflow cases with an amount of primes greater than "
                + MIN_AMOUNT_OF_PRIMES + " and a percentage\ngreater than " + MAX_SPACE_FOR_STARS
                + "%, it will be displayed filling" + " all whitespaces with stars\nshowing " +
                "an overwhelming occurrence.\"";

        return specialCases;
    }


    /*---------------------- displayTotalForSmallNumberOfPrimes ----------------------------
         |  Method displayTotalForSmallNumberOfPrimes(int amountOfPrimes, int[] percentage)
         |
         |Purpose: Display a particular output depending on the amount of primes numbers
         |         required. In this case for an amount less than a fixed number set to
         |         MIN_AMOUNT_OF_PRIMES.
         |
         |  @param amountOfPrimes
         |  @param percentage
         |
         | @return None
         *-------------------------------------------------------------------*/
    private static void displayTotalForSmallNumberOfPrimes(int amountOfPrimes, int[] percentage)
    {
        int spacesInBlank = MAX_NUMBER_OF_COLUMNS + MAX_NUMBER_OF_COLUMNS;
        int totalPercentage = PrimeSequence.NO_VALUE;
        for(int blankSpacesCounter = PrimeSequence.NO_VALUE; blankSpacesCounter < spacesInBlank;
            blankSpacesCounter++)
        {
            System.out.print("_");
        }
        for(int percentageCounter = PrimeSequence.NO_VALUE; percentageCounter < percentage.length;
            percentageCounter++)
        {
            totalPercentage += percentage[percentageCounter];
        }
        System.out.printf("\n%9s%2d, %d%s%s %n", "(", amountOfPrimes, totalPercentage, "%", ")");
        System.out.println("Total(actual count, %)");
    }

    /*---------------------- displayTotalForLargeNumberOfPrimes ----------------------------
         |  Method displayTotalForLargeNumberOfPrimes(int amountOfPrimes, int[] percentage)
         |
         |Purpose: Display a particular output depending on the amount of primes numbers
         |         required. In this case for an amount greater than a fixed number set to
         |         MIN_AMOUNT_OF_PRIMES.
         |
         |  @param amountOfPrimes
         |  @param percentage
         |
         | @return None
         *-------------------------------------------------------------------*/
    private static void displayTotalForLargeNumberOfPrimes(int amountOfPrimes, int[] percentage)
    {
        int spacesInBlank = MAX_SPACE_FOR_STARS + MAX_NUMBER_OF_COLUMNS + MIN_SPACE_FOR_STARS;
        int totalPercentage = PrimeSequence.NO_VALUE;
        for(int blankSpacesCounter = PrimeSequence.NO_VALUE; blankSpacesCounter < spacesInBlank;
            blankSpacesCounter++)
        {
            System.out.print("_");
        }
        for(int percentageCounter = PrimeSequence.NO_VALUE; percentageCounter < percentage.length;
            percentageCounter++)
        {
            totalPercentage += percentage[percentageCounter];
        }
        System.out.print("\nTotal(actual count, %)");
        System.out.printf("%22s%2d, %3d%s%s %n", "(", amountOfPrimes, totalPercentage, "%", ")");
    }

    /*---------------------- displayStars ----------------------------
         |  Method displayStars(int[] percentage, int amountOfPrimes, int[] digitCounterStore,
                                     int digitCounter)
         |
         |Purpose: Display a particular output for the stars in the (as much square
         |         as possible) table depending on the amount of primes numbers
         |         required and if program detected integer overflow or not.
         |
         |  @param percentage
         |  @param amountOfPrimes
         |  @param digitCounterStore
         |  @param digitCounter
         |
         | @return None
         *-------------------------------------------------------------------*/
    private static void displayStars(int[] percentage, int amountOfPrimes, int[] digitCounterStore,
                                     int digitCounter)
    {
        if(amountOfPrimes > MIN_AMOUNT_OF_PRIMES)
        {
            if(percentage[PrimeSequence.NO_VALUE] <= MAX_SPACE_FOR_STARS)
            {
                displayForLargeAmountOfPrimes(percentage, digitCounter);
            }
            else
            {
                displayForOverflow(digitCounter, percentage);
            }

        }
        else
        {
            displayForSmallAmountOfPrimes(digitCounterStore, digitCounter);
        }
    }

    /*---------------------- displayForLargeAmountOfPrimes ----------------------------
         |  Method displayForLargeAmountOfPrimes(int[] percentage, int digitCounter)
         |
         |Purpose: Specific display for a particular output for the stars where
         |         amount of primes numbers is greater than MIN_AMOUNT_OF_PRIMES.
         |         Match stars 1 to 1 with percentage filled left spaces with a
         |         whitespace to completed a total of a fixed number set to
         |         MAX_SPACE_FOR_STARS spaces.
         |
         |  @param percentage
         |  @param digitCounter
         |
         | @return None
         *-------------------------------------------------------------------*/
    private static void displayForLargeAmountOfPrimes(int[] percentage, int digitCounter)
    {
        int spacesInBlank = MAX_SPACE_FOR_STARS - percentage[digitCounter];
        for(int starsCounter = PrimeSequence.NO_VALUE; starsCounter < percentage[digitCounter];
            starsCounter++)
        {
            System.out.print("*");
        }
        for(int blankSpacesCounter = PrimeSequence.NO_VALUE; blankSpacesCounter < spacesInBlank;
            blankSpacesCounter++)
        {
            System.out.print(" ");
        }
    }

    /*---------------------- displayForSmallAmountOfPrimes ----------------------------
         |  Method displayForSmallAmountOfPrimes(int[] digitCounterStore, int digitCounter)
         |
         |Purpose: Specific display for a particular output for the stars where
         |         amount of primes numbers is less than MIN_AMOUNT_OF_PRIMES. Match stars
         |         1 to 1 with the last digit occurrence of every number. Filling left
         |         spaces with whitespaces to complete a total fixed number set to
         |         MIN_SPACE_FOR_STARS spaces.
         |
         |  @param digitCounterStore
         |  @param digitCounter
         |
         | @return None
         *-------------------------------------------------------------------*/
    private static void displayForSmallAmountOfPrimes(int[] digitCounterStore, int digitCounter)
    {
        int spacesInBlank = MIN_SPACE_FOR_STARS - digitCounterStore[digitCounter];
        for(int starsCounter = PrimeSequence.NO_VALUE; starsCounter < digitCounterStore[digitCounter];
            starsCounter++)
        {
            System.out.print("*");
        }
        for(int blankSpacesCounter = PrimeSequence.NO_VALUE; blankSpacesCounter < spacesInBlank;
            blankSpacesCounter++)
        {
            System.out.print(" ");
        }
    }

    /*---------------------- displayForOverflow ----------------------------
         |  Method displayForOverflow(int digitCounter, int[] percentage)
         |
         |Purpose: Specific display for a particular output where program
         |         protects against overflow (when integer number have reach
         |         its max). It fills up spaces with stars, in case of a 100%
         |         for overflow (o representation in the table), it will fill
         |         MAX_SPACE_FOR_STARS fixed spaces available to display stars.
         |         Otherwise it will fill stars matching percentage 1 to 1.
         |
         |  @param digitCounter
         |  @param percentage
         |
         | @return None
         *-------------------------------------------------------------------*/
    private static void displayForOverflow(int digitCounter, int[] percentage)
    {
        int starsCounter = PrimeSequence.NO_VALUE;
        if(digitCounter == PrimeSequence.NO_VALUE)
        {
            for(starsCounter = (percentage[digitCounter] - MAX_SPACE_FOR_STARS);
                starsCounter < percentage[digitCounter]; starsCounter++)
            {
                System.out.print("*");
            }
        }
        else
        {
            int spacesInBlank = MAX_SPACE_FOR_STARS - percentage[digitCounter];
            for(starsCounter = PrimeSequence.NO_VALUE; starsCounter < percentage[digitCounter];
                starsCounter++)
            {
                System.out.print("*");
            }
            for(int blankSpacesCounter = PrimeSequence.NO_VALUE; blankSpacesCounter < spacesInBlank;
                blankSpacesCounter++)
            {
                System.out.print(" ");
            }
        }
    }

    /*---------------------- getPercentage ----------------------------
         |  Method getPercentage(int lastDigitAmount, int amountOfPrimes)
         |
         |Purpose: Compute the percentage of times the last numbers have been
         |         repeated in a total of a desired amount of primes found.
         |         Uses method java.lang.Math.ceil() which returns the double
         |         value that is greater than or equal to the argument and is
         |         equal to the nearest mathematical integer. Please refer to:
         |      https://docs.oracle.com/javase/7/docs/api/java/lang/Math.html
         |
         |  @param lastDigitAmount
         |  @param amountOfPrimes
         |
         | @return None
         *-------------------------------------------------------------------*/
    private static int getPercentage(int lastDigitAmount, int amountOfPrimes)
    {
        int percentage = (int)Math.ceil((lastDigitAmount * FULL_PERCENTAGE) / amountOfPrimes);
        return percentage;
    }

    /*---------------------- displayTableOfPrimes ----------------------------
         |  Method displayTableOfPrimes(int amountOfPrimes, int[] primes, int startNumber)
         |
         |Purpose: Display required primes found in an attractive way (as square
         |         as possible) up to 10 columns.
         |         Uses method java.lang.Math.ceil() which returns the double
         |         value that is greater than or equal to the argument and is
         |         equal to the nearest mathematical integer. Please refer to:
         |      https://docs.oracle.com/javase/7/docs/api/java/lang/Math.html
         |
         |  @param amountOfPrimes
         |  @param primes
         |  @param startNumber
         |
         | @return None
         *-------------------------------------------------------------------*/
    private static void displayTableOfPrimes(int amountOfPrimes, int[] primes, int startNumber)
    {
        int numberOfRows = PrimeSequence.NO_VALUE;
        int numberOfColumns = PrimeSequence.NO_VALUE;

        System.out.println("\nPrime Sequence Table:");
        System.out.println("Printing a sequence of " + amountOfPrimes +
                " prime numbers, starting with the first prime after " + startNumber + ":");

        if(amountOfPrimes > MAX_PRIMES_TO_DISPLAY)
        {
            numberOfColumns = MAX_NUMBER_OF_COLUMNS;
            numberOfRows = (int)(Math.ceil(((double)amountOfPrimes / MAX_NUMBER_OF_COLUMNS)));
        }
        else
        {
            numberOfRows = (int)(Math.ceil(Math.sqrt(amountOfPrimes)));
            numberOfColumns = (int)(Math.ceil(Math.sqrt(amountOfPrimes)));
        }

        displaySquareTable(numberOfRows, numberOfColumns, primes);
        System.out.println("+Table entries of (0) indicate overflow results");
    }

    /*---------------------- displaySquareTable ----------------------------
         |  Method displaySquareTable(int numberOfRows, int numberOfColumns, int[] primes)
         |
         |Purpose: Display an specific square table with up to a fixed
         |         MAX_NUMBER_OF_COLUMNS columns wide.
         |
         |  @param numberOfRows
         |  @param numberOfColumns
         |  @param primes
         |
         | @return None
         *-------------------------------------------------------------------*/
    private static void displaySquareTable(int numberOfRows, int numberOfColumns, int[] primes)
    {
        int primesCounter = PrimeSequence.NO_VALUE;
        int[][] primesSquareTable = new int[numberOfRows][numberOfColumns];
        for(int rowsCounter = PrimeSequence.NO_VALUE; rowsCounter < numberOfRows; rowsCounter++)
        {
            for(int columnsCounter = PrimeSequence.NO_VALUE; columnsCounter < numberOfColumns;
                columnsCounter++)
            {
                if(primesCounter < primes.length)
                {
                    primesSquareTable[rowsCounter][columnsCounter] = primes[primesCounter];
                    primesCounter++;
                    System.out.printf("%12d", primesSquareTable[rowsCounter][columnsCounter]);
                }
            }
            System.out.println();
        }
    }
}
