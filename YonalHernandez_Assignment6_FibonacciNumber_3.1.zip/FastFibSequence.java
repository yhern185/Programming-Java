/*=======================================================================
|     Source code: FastFibSequence.java
|           Class: FastFibSequence
|          Author: Yonal Hernandez
|      Student ID: 6178656
|      Assignment: Program #6 Recursive Fibonacci
|
|          Course: COP3337 Computer Programming II
|         Section: U02
|      Instructor: William Feild
|        Due Date: April 18, 2019 at the beginning of class
|
|	I hereby certify that this collective work is my own
|	and none of it is the work of any other person or entity.
|	_______Yonal Hernandez__________________________________
|
|        Language: Java
|     Compile/Run: Compile
| 	         javac FastFibSequence.java
|
|         Purpose: This class finds the next fibonacci number from a
|   reference number that we called starting number. Implements Sequence
|   class and its next() method. Uses recursion to find the first 2 numbers,
|   and save them into a helper array to find next fibonacci numbers by
|   adding the last two numbers in the array.
|
|   Inherits From: None
|
|      Interfaces: Sequence.java
|
|  +-----------------------------------------------------------------------
|
|       Constants:
|   private final int BASE_FIB = 1;
|       Base case to find a fibonacci number
|   private final int BASE_CONDITION = 2;
|       Fixed number to compare starting number
|   private final int LAST = 1;
|       Used to get last number.
|   private final int BEFORE_LAST = 2;
|       Used to get number before last.
|   private final int MAX_AMOUNT_OF_FIB = 36;
|       Max amount of fibonacci numbers to be found.
|   private final int NO_VALUE = 0;
|       Uses for initialization purposes.
|
| +-----------------------------------------------------------------------
|
|    Constructors:
|   public FastFibSequence()
|       Default constructor for the class. Initialize starting number to 1.
|
|   public FastFibSequence(int startingNumber)
|       Initialize starting number to desired starting number.
|
|   Class Methods:
|   private int fibFinder(int startingNumber)
|       return fibFound;
|
|Instance Methods:
|   public int next()
|       return fibNumber;
|
|  *===========================================================================*/


public class FastFibSequence implements Sequence
{
    private final int BASE_FIB = 1;
    private final int BASE_CONDITION = 2;
    private final int LAST = 1;
    private final int BEFORE_LAST = 2;
    private final int MAX_AMOUNT_OF_FIB = 36;
    private final int NO_VALUE = 0;

    private int startingNumber = NO_VALUE;
    private int fibFound = NO_VALUE;
    private int fibNumber = NO_VALUE;
    private int speedCounter = NO_VALUE;
    private int[] fibFoundSpeedHelper = new int[MAX_AMOUNT_OF_FIB];

    /*---------------------- FastFibSequence ----------------------------
         |  Method FastFibSequence()
         |
         |Purpose: Default constructor for the class. Initialize starting
         |  number to 1.
         |
         |  @param None
         |
         | @return None
         *-------------------------------------------------------------------*/
    public FastFibSequence()
    {
        startingNumber = BASE_FIB;
    }

    /*---------------------- FastFibSequence ----------------------------
         |  Method FastFibSequence(int startingNumber)
         |
         |Purpose: Initialize starting number to desired starting number.
         |
         |  @param startingNumber
         |
         | @return None
         *-------------------------------------------------------------------*/
    public FastFibSequence(int startingNumber)
    {
        this.startingNumber = startingNumber;
    }

    /*------------------------------ next ----------------------------
         |  Method next()
         |
         |Purpose: Implements next() method from the Sequence Interface. Find
         |  next fibonacci number using a helper method and a helper array to
         |  speed up recursive process. Throws a ArithmeticException is next
         |  value overflow.
         |  First increments starting number to start with next (per requirements)
         |
         |  @param None
         |
         | @return fibNumber
         *-------------------------------------------------------------------*/
    public int next()
    {
        startingNumber++;
        if(startingNumber < BASE_FIB)
        {
            return fibNumber = NO_VALUE;
        }
        fibNumber = fibFinder(startingNumber);
        fibFoundSpeedHelper[speedCounter] = fibNumber;
        speedCounter++;
        if(fibNumber < NO_VALUE)
        {
            throw new ArithmeticException("Arithmetic Overflow: ");
        }
        return fibNumber;
    }

    /*------------------------------ fibFinder ----------------------------
         |  Method fibFinder(int startingNumber)
         |
         |Purpose: Private method to be use only by the next() method. It finds
         |  the next fibonacci number using a fast recursive method and saves
         |  them into a helper array to compute the next fibonacci number by
         |  adding the last 2 numbers in the array.
         |
         |  @param fibFound
         |
         | @return fibNumber
         *-------------------------------------------------------------------*/
    private int fibFinder(int startingNumber)
    {

        if(speedCounter > BASE_FIB)
        {
            fibFound = fibFoundSpeedHelper[speedCounter - LAST] +
                    fibFoundSpeedHelper[speedCounter - BEFORE_LAST];
        }
        else if(startingNumber > BASE_CONDITION)
        {
            fibFound = fibFinder(startingNumber - LAST) +
                    fibFinder(startingNumber - BEFORE_LAST);
        }
        else
        {
            fibFound = BASE_FIB;
        }
        return fibFound;
    }
}
