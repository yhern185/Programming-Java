/*=============================================================================
|   Source code: FibDemo.java
|        Author: Yonal Hernandez
|    Student ID: 6178656
|    Assignment: Program #6 Recursive Fibonacci
|
|        Course: COP3337 Computer Programming II
|       Section: U02
|    Instructor: William Feild
|      Due Date: April 18, 2019 at the beginning of class
|
|	I hereby certify that this collective work is my own
|	and none of it is the work of any other person or entity.
|	_______Yonal Hernandez__________________________________
|
|      Language: Java
|   Compile/Run: Compile and run
|   *Presence of InputFile and Sequence.java Interface in the same directory is required.
|   *InputFile must contain two integers separate by a newline character.
|       > The first integer in the input file dictates where the Fibonacci sequence will
|         start, beginning with the next Fibonacci number from [0-12].
|       > The second integer in the input file will be the number of Fibonacci numbers
|         to be displayed in the tables from [1-36].
|   *Two file names need to be passed as arguments in the
|    command-line at run time. ex: InputFile OutputFile
| 	       javac FibDemo.java  LoopFibSequence.java  FibSequence.java
|                FastFibSequence.java  FibStopWatch.java
|                UserInvalidValueException.java Sequence.java
|	       java  FibDemo InputFile OutputFile
|
|  +-----------------------------------------------------------------------------
|   **EXTRA CREDIT ATTEMPTED: Array-out-of-Bounds, File-OverWrite, Arithmetic-Overflow**
|
|  Description: Program compute and create three tables for the Fibonacci numbers:
|   one iterative, one recursive, and one ‘fast recursive’. Refer in the textbook
|   to problem E13.20 on page 624, which expands section 13.3. This class will produce
|   the three tables of n Fibonacci numbers, three classes (LoopFibSequence,
|   FibSequence, and FastFibSequence) that each implements the next() method as
|   provided in a Sequence interface The number of Fibonacci numbers to be provided in
|   the tables (n) will be input from the input file, and the three tables
|   themselves will be output to a file - both file names to be found on the command-line
|   upon execution of the FibDemo class.
|
|        Input: The name of the input file and the output file (no file extension is
|   required, but is permitted) will be specified on the command-line. The first integer
|   in the input file dictates where the Fibonacci sequence will start, beginning with
|   the next Fibonacci number. The second integer in the input file will be the number
|   of Fibonacci numbers to be displayed in the tables. The integer values in the input
|   file will need to be [0-12] & [1-36], respectively, and inclusive. A newline will
|   separate the two integer values.
|
|       Output: The output file will contain one table of iteratively-computed Fibonacci
|   integers (the “expected” values); a second table of recursively-computed Fibonacci
|   integers; followed by a third table of ‘fast’ recursively-computed Fibonacci integers.
|   The output file name will be specified on the command-line. All tables will be
|   labeled, values right-aligned, “square-ish”, and clearly have identical values.
|   Additionally, the execution time (in nanoseconds) to compute all of the values for
|   each table will be printed/labeled, following each table, for comparison purposes
|   The execution time will be computed in nanoseconds, but the display will show the
|   execution time in both nanoseconds and seconds (display seconds to four-decimal place
|   accuracy).
|
|      Process:
|   1. Validate input handling IOException in case of no arguments in the command
|      line, FileNotFoundException if the file do not exits in the same directory,
|      UserInvalidValueException if there are not two valid integers inside the file in
|      [0-12] & [1-36] respectively separated by a newline character.
|   2. Validate output handling FileAlreadyExistsException preventing user from
|      overwrite output file by mistake.
|   3. Define the starting number and the amount of fibonacci numbers to be found.
|   4. Compute number of columns in order to display results in output file in a
|      “square-ish” as possible table.
|   5. Create an object from FibStopWatch class to measure the time each method needs
|      to find the fibonacci numbers.
|   6. Display a courtesy message to the user informing about the time (approximate)
|      program will need to finish.
|   7. Display computed data in the specified output file.
|   8. Display a courtesy message informing user that program finished and output file
|      has the required information.
|
|   Required Features Not Included: None
|
|   Known Bugs: None
|
|   import java.io.File;  Input and output to files.
|   import java.io.IOException;  General class of exceptions produced by failed or
|       interrupted I/O operations.
|   import java.io.FileNotFoundException;  Signals that an attempt to open the file
|       denoted by a specified pathname has failed.
|   import java.io.PrintWriter;  Prints formatted representations of objects to a
|       text-output stream. This class implements all of the print methods.
|   import java.lang.ArrayIndexOutOfBoundsException;  Thrown to indicate that an array
|       has been accessed with an illegal index. The index is either negative or
|       greater than or equal to the size of the array.
|   import java.util.Scanner;  Read data from the InputFile and user responses.
|   import java.nio.file.FileAlreadyExistsException; Checked exception thrown when an
|       attempt is made to create a file or directory and a file of that name already
|       exists.
|   import java.lang.ArithmeticException; Thrown when an exceptional arithmetic
|       condition has occurred. It is used to alert about Arithmetic Overflow when
|       finding fibonacci numbers.
|
|   private static final int INDEX_0 = 0;
|       Used as starting number for counters going throughout an array.
|   private static final int INDEX_1 = 1;
|       Used to check por position in the String[] from the command line input.
|   private static final int NEEDED_ARGS = 2;
|       Fixed number to defined the size of the array that will hold the values for the
|       starting number and the amount of fibonacci numbers.
|   private static final int MAX_AMOUNT_OF_FIB_NUMBERS = 36;
|       Maximum amount of fibonacci numbers allowed.
|   private static final int MIN_AMOUNT_OF_FIB_NUMBERS = 1;
|       Minimum amount of fibonacci numbers allowed.
|   private static final int MAX_STARTING_NUMBER = 12;
|       Maximum starting number allowed.
|   private static final int MIN_STARTING_NUMBER = 0;
|       Minimum starting number allowed.
|   private static final int OVERWRITE = 1;
|       Fixed number to check for overwrite options.
|   private static final int NEW_FILE_NAME = 2;
|       Fixed number to check for overwrite options.
|   private static final int EXIT = 3;
|       Fixed number to check for overwrite options.
|   private static final int BREAK_POINT_ONE = 30;
|       Fixed number where computation time change significantly.
|   private static final int BREAK_POINT_TWO = 10;
|       Fixed number where computation time change significantly.
|   private static final int TIME_GUARANTEED = 5;
|       Fixed number that guaranteed wait time message.
|   private static final String TIME_IN_SECONDS = " Seconds";
|       Used to display courtesy wait time message. Good practice to has it as final
|       to be easily change in the future.
|   private static final String TIME_IN_NANOSECONDS = " Nanoseconds";
|       Used to display courtesy wait time message. Good practice to has it as final
|       to be easily change in the future.
|  *===========================================================================*/

import java.io.File;
import java.io.IOException;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.lang.ArrayIndexOutOfBoundsException;
import java.nio.file.FileAlreadyExistsException;
import java.lang.ArithmeticException;
import java.util.Scanner;

public class FibDemo
{
    private static final int INDEX_0 = 0;
    private static final int INDEX_1 = 1;
    private static final int NEEDED_ARGS = 2;
    private static final int MAX_AMOUNT_OF_FIB_NUMBERS = 36;
    private static final int MIN_AMOUNT_OF_FIB_NUMBERS = 1;
    private static final int MAX_STARTING_NUMBER = 12;
    private static final int MIN_STARTING_NUMBER = 0;
    private static final int OVERWRITE = 1;
    private static final int NEW_FILE_NAME = 2;
    private static final int BREAK_POINT_ONE = 30;
    private static final int BREAK_POINT_TWO = 9;
    private static final int TIME_GUARANTEED = 5;
    private static final String TIME_IN_SECONDS = " Seconds";
    private static final String TIME_IN_NANOSECONDS = " Nanoseconds";

    public static void main(String[] commandLineInput)
    {
        try
        {
            int[] validatedInput = validateInput(commandLineInput);
            String outputFile = validateOutput(commandLineInput[INDEX_1]);
            PrintWriter outFile = new PrintWriter(outputFile);
            final int STARTING_NUMBER = validatedInput[INDEX_0];
            final int AMOUNT_OF_FIB_NUMBERS = validatedInput[INDEX_1];
            final int NUMBER_OF_COLUMNS =
                    (int)(Math.ceil(Math.sqrt(AMOUNT_OF_FIB_NUMBERS)));
            FibStopWatch fibStopWatch = new FibStopWatch();
            displayWaitTime(STARTING_NUMBER, AMOUNT_OF_FIB_NUMBERS, outputFile);
            displayDataOnFile(AMOUNT_OF_FIB_NUMBERS, STARTING_NUMBER,
                    fibStopWatch, outFile, NUMBER_OF_COLUMNS);
            displayCompletionMessage();
        }
        catch (ArrayIndexOutOfBoundsException exception)
        {
            exception.printStackTrace();
            System.exit(1);
        }
        catch (IOException exception)
        {
            System.out.println(exception.getMessage());
            System.exit(1);
        }

    }

    /*---------------------- displayCompletionMessage ----------------------------
         |  Method displayCompletionMessage()
         |
         |Purpose: Courtesy message to let the user know the computations are completed
         |         and output file is ready.
         |
         |  @param None
         |
         | @return None
         *-------------------------------------------------------------------*/
    private static void displayCompletionMessage()
    {
        System.out.println("\nProcess completed. Please check output file.");
    }

    /*---------------------- displayWaitTime ----------------------------
         |  Method displayWaitTime(int startingNumber, int amountOfFibNumbers,
         |                              String outputFile)
         |
         |Purpose: Courtesy message to let the user know the approximate wait time
         |  for the program to finish.
         |  *Approximate wait time can vary from moment to moment, displayed numbers
         |   are not a 100% accurate, however, it provides a roughly idea of what is
         |   happening with the program.
         |  BREAK_POINT_ONE and BREAK_POINT_TWO are fixed number selected from a
         |  certain number of test and were identified as critical points where time
         |  fluctuates significantly.
         |
         |  @param startingNumber
         |  @param amountOfFibNumbers
         |  @param outputFile
         |
         | @return None
         *-------------------------------------------------------------------*/
    private static void displayWaitTime(int startingNumber, int amountOfFibNumbers,
                                        String outputFile)
    {
        System.out.println("Collecting data to display in File: "
                + outputFile);
        if((amountOfFibNumbers < BREAK_POINT_ONE) ||
            (startingNumber < BREAK_POINT_TWO))
        {
            System.out.println("Approximate wait time is less than: " +
                    (startingNumber + TIME_GUARANTEED) + TIME_IN_SECONDS);
        }
        else
        {
            System.out.println("Approximate wait time is less than: " +
                    (amountOfFibNumbers + TIME_GUARANTEED) + TIME_IN_SECONDS);
        }

    }

    /*---------------------- displayDataOnFile ----------------------------
         |  Method displayDataOnFile(int amountOfFibNumbers,
         |                                int startingNumber, FibStopWatch fibStopWatch,
         |                                PrintWriter outFile, int numberOfColumns)
         |      throws ArrayIndexOutOfBoundsException
         |
         |Purpose: Display data to the output file. A trio of separate loops is
         |  executed - each requesting the next Fibonacci number - the requisite
         |  number of times. System time, taken before and after each loop, gathered
         |  via fibStopWatch facilitate the determination of the execution time for each
         |  table. If any exception occurs method closes the before termination saving
         |  any collected information.
         |
         |  @param amountOfFibNumbers
         |  @param startingNumber
         |  @param fibStopWatch
         |  @param outFile
         |  @param numberOfColumns
         |
         | @return None
         *-------------------------------------------------------------------*/
    private static void displayDataOnFile(int amountOfFibNumbers,
                                          int startingNumber, FibStopWatch fibStopWatch,
                                          PrintWriter outFile, int numberOfColumns)
            throws ArrayIndexOutOfBoundsException
    {
        try
        {
            iterativeSolution(amountOfFibNumbers, startingNumber,
                        fibStopWatch, outFile, numberOfColumns);
            recursiveSolution(amountOfFibNumbers, startingNumber,
                        fibStopWatch, outFile, numberOfColumns);
            fastRecursiveSolution(amountOfFibNumbers, startingNumber,
                        fibStopWatch, outFile, numberOfColumns);
            outFile.println("Note: In some cases the process is so fast that there" +
                    " is no result reflected");
            outFile.println("in the \"seconds\" value. This DO NOT means " +
                    "no time passed, however, 4 decimal");
            outFile.println("places is a small range to capture such small values.");
        }
        finally
        {
            outFile.close();
        }

    }

    /*---------------------- validateOutput ----------------------------
         |  Method validateOutput(String outputFileName)
         |   throws ArrayIndexOutOfBoundsException
         |
         |Purpose: Validate OutputFile name if any, throws ArrayIndexOutOfBoundsException
         |  if there is no second element in the command line input.  Uses
         |  FileAlreadyExistsException class to prevent undesired overwrite issues.
         |  For more information about it, please refer to:
         |  https://docs.oracle.com/javase/7/docs/api/java/nio/file
         |                                               /FileAlreadyExistsException.html
         |
         |  @param outputFileName
         |
         | @return outputFile
         *-------------------------------------------------------------------*/
    private static String validateOutput(String outputFileName)
            throws ArrayIndexOutOfBoundsException
    {
        String outputFile = outputFileName;
        try
        {
            outputFile = checkForOverwrite(outputFileName);

        }
        catch (FileAlreadyExistsException exception)
        {
            System.out.println("\n" + exception.getMessage());
            System.exit(1);
        }
        return outputFile;
    }

    /*---------------------- checkForOverwrite ----------------------------
         |  Method checkForOverwrite(String outputFileName)
         |  throws FileAlreadyExistsException
         |
         |Purpose: Prevent undesired overwrite issues by letting the user know that
         |  the file already exist and offering some options.
         |  Option1 for overwrite, Option2 for introduce a new file name and option3
         |  to quit. User will need to pass new output file name in case a new
         |  file name is desired. Throws FileAlreadyExistsException to be catch
         |  by his caller. Uses method exists() from the File class, it tests
         |  whether the file or directory denoted by this abstract pathname exists,
         |  returns true if and only if the file or directory denoted by this
         |  abstract pathname exists; false otherwise. For more information please
         |  refer to:
         |  https://docs.oracle.com/javase/7/docs/api/java/io/File.html#exists()
         |
         |  @param outputFileName
         |
         | @return outputFileName
         *-------------------------------------------------------------------*/
    private static String checkForOverwrite(String outputFileName)
            throws FileAlreadyExistsException
    {
        File testFileName = new File(outputFileName);
        if(testFileName.exists())
        {
            System.out.println("\nFile already exist.");
            Scanner decision = new Scanner(System.in);
            int decidedNumber = checkDecision(decision);
            if(decidedNumber == NEW_FILE_NAME)
            {
                do
                {
                    System.out.println("\nPlease enter new file name");
                    outputFileName = decision.next();
                }
                while(outputFileName.isEmpty());
                outputFileName = checkForOverwrite(outputFileName);
            }
            else
            {
                System.out.println("\nOverwriting existing file.");
            }
        }
        return outputFileName;
    }

    /*---------------------- checkDecision ----------------------------
         |  Method checkDecision(Scanner decision)
         |
         |Purpose: Validate option selected by user (1 or 2) making sure that
         |  one of the two options is selected quitting program otherwise
         |  by throwing a FileAlreadyExistsException.
         |
         |  @param decision
         |
         | @return decisionNumber
         *-------------------------------------------------------------------*/
    private static int checkDecision(Scanner decision) throws FileAlreadyExistsException
    {
        int decisionNumber = INDEX_0;
        displayOptions();
        if(!decision.hasNextInt())
        {
            throw new FileAlreadyExistsException("EXITING PROGRAM");
        }
        else
        {
            decisionNumber = decision.nextInt();
            if((decisionNumber < OVERWRITE) || (decisionNumber > NEW_FILE_NAME))
            {
                throw new FileAlreadyExistsException("EXITING PROGRAM");
            }
        }
        return decisionNumber;
    }

    /*---------------------- displayOptions ----------------------------
         |  Method displayOptions()
         |
         |Purpose: Display a message to the user to inform the options it has,
         |  1 for overwrite, 2 for change file name or any other key to quit.
         |
         |  @param None
         |
         | @return None
         *-------------------------------------------------------------------*/
    private static void displayOptions()
    {
        System.out.println("Please enter:\n" + OVERWRITE + " for OVERWRITE.\n" +
                NEW_FILE_NAME + " for SPECIFY NEW FILE NAME.\n" +
                "ANY OTHER KEY for EXIT");
    }

    /*---------------------- validateInput ----------------------------
         |  Method validateInput(String[] commandLineInput)
         |      throws ArrayIndexOutOfBoundsException IOException
         |
         |Purpose: Create a new File object with the name of the Input File found in the
         |  command line input if any, throws an ArrayIndexOutOfBoundsException in case
         |  of incorrect input in the command line, and let the user know how the input
         |  should be in the command line input. Uses a object from the scanner class to
         |  check data inside the file. Catches FileNotFoundException if input file name
         |  do no exist in the directory.
         |
         |  @param commandLineInput
         |
         | @return validInput
         *-------------------------------------------------------------------*/
    private static int[] validateInput(String[] commandLineInput)
            throws ArrayIndexOutOfBoundsException, IOException
    {
        if(commandLineInput.length != NEEDED_ARGS)
        {
            throw new IOException("\nTwo parameters need to be pass" +
                    " in the command line. Example:\n java FibDemo InputFile OutputFile");
        }
        else
        {
            int[] validInput = new int[NEEDED_ARGS];
            try
            {
                File inputFile = new File(commandLineInput[INDEX_0]);
                Scanner inFile = new Scanner(inputFile);
                validInput = validateData(inFile);
            }
            catch (FileNotFoundException exception)
            {
                System.out.println("\nFile " + commandLineInput[INDEX_0] + " not found. " +
                        "Please pass an existing filename as first parameter in the " +
                        "command line.");
                System.exit(1);
            }
            return validInput;
        }
    }

    /*---------------------- validateData ----------------------------
         |  Method validateData(Scanner inFile) throws ArrayIndexOutOfBoundsException
         |
         |Purpose: Try to validate data in the input file and save it into an array.
         |  If any exception happens it closes the file first and the handle it.
         |  Catches UserInvalidValueException in case not acceptable values for
         |  starting number and amount of fibonacci numbers are not found in the
         |  inputFile. It also throw an UserInvalidValueException if more data than
         |  necessary is found in the file.
         |
         |  @param inFile
         |
         | @return validInput
         *-------------------------------------------------------------------*/
    private static int[] validateData(Scanner inFile) throws ArrayIndexOutOfBoundsException
    {
        int[] validInput = new int[NEEDED_ARGS];
        try
        {
            try
            {
                for(int validValuesCounter = INDEX_0;
                    validValuesCounter < validInput.length; validValuesCounter++)
                {
                    checkForIntegers(inFile, validValuesCounter, validInput);
                }
                if(inFile.hasNext())
                {
                    throw new UserInvalidValueException("More data than expected inside " +
                            "InputFile.");
                }
            }
            finally
            {
                inFile.close();
            }
        }
        catch (UserInvalidValueException exception)
        {
            System.out.println("\nUser Invalid Value Exception: " + exception.getMessage());
            System.exit(1);
        }
        return validInput;
    }


    /*---------------------- checkForIntegers ----------------------------
         |  Method checkForIntegers(Scanner inFile, int validValuesCounter,
         |                                int[] validInput) throws UserInvalidValueException
         |
         |Purpose: Checks if two acceptable integer values are found inside the input file.
         |  throws UserInvalidValueException if there is not integers numbers or they
         |  are not in the valid range.
         |
         |  @param inFile
         |  @param validValuesCounter
         |  @param validInput
         |
         | @return None
         *-------------------------------------------------------------------*/
    private static void checkForIntegers(Scanner inFile, int validValuesCounter,
                                          int[] validInput) throws UserInvalidValueException
    {
        if(!inFile.hasNextInt())
        {
            throw new UserInvalidValueException("Parameter " + (validValuesCounter + INDEX_1) +
                    " in the input file is NOT an Integer Number.");
        }
        else
        {
            int integer = inFile.nextInt();
            if(validValuesCounter == INDEX_0)
            {
                if((integer < MIN_STARTING_NUMBER) || (integer > MAX_STARTING_NUMBER))
                {
                    throw new UserInvalidValueException("Invalid starting number. It " +
                            "needs to be an integer number between " +
                            MIN_STARTING_NUMBER + " and " + MAX_STARTING_NUMBER);
                }
            }
            else
            {
                if ((integer < MIN_AMOUNT_OF_FIB_NUMBERS) ||
                        (integer > MAX_AMOUNT_OF_FIB_NUMBERS))
                {
                    throw new UserInvalidValueException("Invalid amount of Fibonacci " +
                            "numbers required. It needs to be and integer between: " +
                            MIN_AMOUNT_OF_FIB_NUMBERS + " and " + MAX_AMOUNT_OF_FIB_NUMBERS);
                }
            }
            validInput[validValuesCounter] = integer;
        }
    }


    /*---------------------- fastRecursiveSolution ----------------------------
         |  Method fastRecursiveSolution(int amountOfFibNumbers, int startingNumber,
         |                                    FibStopWatch fibStopWatch, PrintWriter outFile,
         |                                    int numberOfColumns)
         |      throws ArrayIndexOutOfBoundsException
         |
         |Purpose: Creates an object from the FastFibSequence class to collect all
         |  the fibonacci numbers into an array while measure the time in needs to do so.
         |  Catches an ArithmeticException in case numbers overflow and display it
         |  in the output file, or if division by zero is detected when converting nanoseconds
         |  to seconds.
         |  Throws ArrayIndexOutOfBoundsException is index is negative or if
         |  it is greater than the size of the array.
         |
         |  @param amountOfFibNumbers
         |  @param startingNumber
         |  @param fibStopWatch
         |  @param outFile
         |  @param numberOfColumns
         |
         | @return None
         *-------------------------------------------------------------------*/
    private static void fastRecursiveSolution(int amountOfFibNumbers, int startingNumber,
                                              FibStopWatch fibStopWatch, PrintWriter outFile,
                                              int numberOfColumns)
            throws ArrayIndexOutOfBoundsException
    {
        FastFibSequence fastRecursiveFib = new FastFibSequence(startingNumber);
        fibStopWatch.start();
        int[] fastRecursiveFibFound = new int[amountOfFibNumbers];
        try
        {
            for(int fastRecursiveCounter = INDEX_0;
                fastRecursiveCounter < fastRecursiveFibFound.length; fastRecursiveCounter++)
            {
                fastRecursiveFibFound[fastRecursiveCounter] = fastRecursiveFib.next();
            }
        }
        catch(ArithmeticException exception)
        {
            outFile.println(exception.getMessage() +
                    "Stars(*) values in the table means Arithmetic Overflow");
        }
        fibStopWatch.stop();
        outFile.println("Fast Recursive");
        createSquareTable(fastRecursiveFibFound, numberOfColumns, outFile);
        try
        {
            outFile.printf("%n%s %,10d %s%s", "Time to compute:",
                    fibStopWatch.getElapsedTimeInNanoseconds(), TIME_IN_NANOSECONDS, ",");
            outFile.printf("%8.4f %s %n%n", fibStopWatch.getElapsedTimeInSeconds(),
                    TIME_IN_SECONDS);
        }
        catch(ArithmeticException exception)
        {
            System.out.println("Division by zero detected.");
            exception.printStackTrace();
            System.exit(1);
        }
    }

    /*---------------------- recursiveSolution ----------------------------
         |  Method recursiveSolution(int amountOfFibNumbers, int startingNumber,
         |                                FibStopWatch fibStopWatch, PrintWriter outFile,
         |                                int numberOfColumns)
         |      throws ArrayIndexOutOfBoundsException
         |
         |Purpose: Creates an object from the FibSequence class to collect all
         |  the fibonacci numbers into an array while measure the time in needs to do so.
         |  Catches an ArithmeticException in case numbers overflow and display it
         |  in the output file, or if division by zero is detected when converting nanoseconds
         |  to seconds.
         |  Throws ArrayIndexOutOfBoundsException is index is negative or if
         |  it is greater than the size of the array.
         |
         |  @param amountOfFibNumbers
         |  @param startingNumber
         |  @param fibStopWatch
         |  @param outFile
         |  @param numberOfColumns
         |
         | @return None
         *-------------------------------------------------------------------*/
    private static void recursiveSolution(int amountOfFibNumbers, int startingNumber,
                                          FibStopWatch fibStopWatch, PrintWriter outFile,
                                          int numberOfColumns)
            throws ArrayIndexOutOfBoundsException
    {
        FibSequence recursiveFib = new FibSequence(startingNumber);
        fibStopWatch.start();
        int[] recursiveFibFound = new int[amountOfFibNumbers];
        try
        {
            for(int recursiveCounter = INDEX_0; recursiveCounter < recursiveFibFound.length;
                recursiveCounter++)
            {
                recursiveFibFound[recursiveCounter] = recursiveFib.next();
            }
        }
        catch(ArithmeticException exception)
        {
            outFile.println(exception.getMessage() +
                    "Stars(*) values in the table means Arithmetic Overflow");
        }
        fibStopWatch.stop();
        outFile.println("Normal Recursive");
        createSquareTable(recursiveFibFound, numberOfColumns, outFile);
        try
        {
            outFile.printf("%n%s %,10d %s%s", "Time to compute:",
                    fibStopWatch.getElapsedTimeInNanoseconds(), TIME_IN_NANOSECONDS, ",");
            outFile.printf("%8.4f %s %n%n", fibStopWatch.getElapsedTimeInSeconds(),
                    TIME_IN_SECONDS);
        }
        catch(ArithmeticException exception)
        {
            System.out.println("Division by zero detected.");
            exception.printStackTrace();
            System.exit(1);
        }
    }

    /*---------------------- iterativeSolution ----------------------------
         |  Method iterativeSolution(int amountOfFibNumbers, int startingNumber,
         |                                FibStopWatch fibStopWatch, PrintWriter outFile,
         |                                int numberOfColumns)
         |      throws ArrayIndexOutOfBoundsException
         |
         |Purpose: Creates an object from the FibSequence class to collect all
         |  the fibonacci numbers into an array while measure the time in needs to do so.
         |  Catches an ArithmeticException in case numbers overflow and display it
         |  in the output file, or if division by zero is detected when converting nanoseconds
         |  to seconds.
         |  Throws ArrayIndexOutOfBoundsException is index is negative or if
         |  it is greater than the size of the array.
         |
         |  @param amountOfFibNumbers
         |  @param startingNumber
         |  @param fibStopWatch
         |  @param outFile
         |  @param numberOfColumns
         |
         | @return None
         *-------------------------------------------------------------------*/
    private static void iterativeSolution(int amountOfFibNumbers, int startingNumber,
                                          FibStopWatch fibStopWatch, PrintWriter outFile,
                                          int numberOfColumns)
            throws ArrayIndexOutOfBoundsException
    {
        LoopFibSequence loopFib = new LoopFibSequence(startingNumber);
        fibStopWatch.start();
        int[] loopFibFound = new int[amountOfFibNumbers];
        try
        {
            for(int loopCounter = INDEX_0; loopCounter < loopFibFound.length;
                loopCounter++)
            {
                loopFibFound[loopCounter] = loopFib.next();
            }
        }
        catch(ArithmeticException exception)
        {
            outFile.println(exception.getMessage() +
                    "Stars(*) values in the table means Arithmetic Overflow");
        }
        fibStopWatch.stop();
        outFile.println("Iterative - Expected");
        createSquareTable(loopFibFound, numberOfColumns, outFile);
        try
        {
            outFile.printf("%n%s %,10d %s%s", "Time to compute:",
                    fibStopWatch.getElapsedTimeInNanoseconds(), TIME_IN_NANOSECONDS, ",");
            outFile.printf("%8.4f %s %n%n", fibStopWatch.getElapsedTimeInSeconds(),
                    TIME_IN_SECONDS);
        }
        catch(ArithmeticException exception)
        {
            System.out.println("Division by zero detected.");
            exception.printStackTrace();
            System.exit(1);
        }
    }

    /*---------------------- createSquareTable ----------------------------
         |  Method createSquareTable(int[] arrayOfFibNumbers,
         |                                int numberOfColumns, PrintWriter outFile)
         |      throws ArrayIndexOutOfBoundsException
         |
         |Purpose: Prints the array with all the fibonacci numbers found in the
         |  most square possible table. If it found a 0 in the array it prints
         |  stars(*) in the table to show arithmetic overflow.
         |  Throws ArrayIndexOutOfBoundsException is index is negative or if
         |  it is greater than the size of the array.
         |
         |  @param arrayOfFibNumbers
         |  @param numberOfColumns
         |  @param outFile
         |
         | @return None
         *-------------------------------------------------------------------*/
    private static void createSquareTable(int[] arrayOfFibNumbers,
                                          int numberOfColumns, PrintWriter outFile)
            throws ArrayIndexOutOfBoundsException
    {
        int columnsCounter = INDEX_0;
        for(int arrayOfFibNumbersCounter = INDEX_0;
            arrayOfFibNumbersCounter < arrayOfFibNumbers.length; arrayOfFibNumbersCounter++)
        {
            if(arrayOfFibNumbers[arrayOfFibNumbersCounter] > INDEX_0)
                if(columnsCounter < numberOfColumns)
                {
                    outFile.printf("%12d", arrayOfFibNumbers[arrayOfFibNumbersCounter]);
                    columnsCounter++;
                }
                else
                {
                    outFile.println();
                    columnsCounter = INDEX_0;
                    arrayOfFibNumbersCounter--;
                }
            else
            {
                outFile.printf("%12s", "**********");
                columnsCounter++;
            }
        }
    }
}
