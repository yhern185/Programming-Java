/*=======================================================================
|     Source code: FibSequence.java
|           Class: FibSequence
|          Author: Yonal Hernandez
|      Student ID: 6178656
|      Assignment: Program #6 Recursive Fibonacci
|
|          Course: COP3337 Computer Programming II
|         Section: U02
|      Instructor: William Feild
|        Due Date: April 18, 2019 at the beginning of class
|
|	I hereby certify that this collective work is my own
|	and none of it is the work of any other person or entity.
|	_______Yonal Hernandez__________________________________
|
|        Language: Java
|     Compile/Run: Compile
| 	         javac FibSequence.java
|
|         Purpose: This class finds the next fibonacci number from a
|   reference number that we called starting number. Implements Sequence
|   class and its next() method. Use worked example from textbook
|   Big Java: Early Objects, 5th Edition page page 598-600 for a recursive
|   solution.
|
|   Inherits From: None
|
|      Interfaces: Sequence.java
|
|  +-----------------------------------------------------------------------
|
|       Constants:
|   private final int BASE_FIB = 1;
|       Base case for the fibonacci numbers. Value assigned for the fib(1)
|       and fib(2).
|   private final int BASE_CONDITION = 2;
|       Base condition to compare starting fibonacci number.
|   private final int NO_VALUE = 0;
|       Fixed number to initialize variables.
|   private final int LAST = 1;
|       Used to get last number.
|   private final int BEFORE_LAST = 2;
|       Used to get number before last.
|
| +-----------------------------------------------------------------------
|
|    Constructors:
|   public FibSequence()
|       Default constructor for the class. Initialize starting number to 1.
|
|   public FibSequence(int startingNumber)
|       Initialize starting number to desired starting number.
|
|   Class Methods:
|   private int fibFinder(int startingNumber)
|       return fibFound;
|
|Instance Methods:
|   public int next()
|       return fibNumber;
|
|  *===========================================================================*/

public class FibSequence implements Sequence
{
    private final int BASE_FIB = 1;
    private final int BASE_CONDITION = 2;
    private final int NO_VALUE = 0;
    private final int LAST = 1;
    private final int BEFORE_LAST = 2;

    private int startingNumber = NO_VALUE;
    private int fibFound = NO_VALUE;
    private int fibNumber = NO_VALUE;

    /*---------------------- FibSequence ----------------------------
         |  Method FibSequence()
         |
         |Purpose: Default constructor for the class. Initialize starting
         |  number to 1.
         |
         |  @param None
         |
         | @return None
         *-------------------------------------------------------------------*/
    public FibSequence()
    {
        startingNumber = BASE_FIB;
    }

    /*---------------------- FibSequence ----------------------------
         |  Method FibSequence(int startingNumber)
         |
         |Purpose: Initialize starting number to desired starting number.
         |
         |  @param startingNumber
         |
         | @return None
         *-------------------------------------------------------------------*/
    public FibSequence(int startingNumber)
    {
        this.startingNumber = startingNumber;
    }

    /*------------------------------ next ----------------------------
         |  Method next()
         |
         |Purpose: Implements next() method from the Sequence Interface. Find
         |  next fibonacci number using a recursive process in a helper method.
         |  Throws a ArithmeticException is next value overflow.
         |  First increments starting number to start with next (per requirements)
         |
         |  @param None
         |
         | @return fibNumber
         *-------------------------------------------------------------------*/
    public int next() throws ArithmeticException
    {
        startingNumber++;
        if(startingNumber < BASE_FIB)
        {
            return fibNumber = NO_VALUE;
        }
        fibNumber = fibFinder(startingNumber);
        if(fibNumber < NO_VALUE)
        {
            throw new ArithmeticException("Arithmetic Overflow: ");
        }
        return fibNumber;
    }

    /*------------------------------ fibFinder ----------------------------
         |  Method fibFinder(int startingNumber)
         |
         |Purpose: Private method to be use only by the next() method. It finds
         |  the fibonacci numbers using the recursive solution. Method keep
         |  calling itself until it reach a base case where the result is 1, and
         |  then goes back adding the last 2 fibonacci numbers.
         |
         |  @param fibFound
         |
         | @return fibNumber
         *-------------------------------------------------------------------*/
    private int fibFinder(int startingNumber)
    {
        if(startingNumber <= BASE_CONDITION)
        {
            fibFound = BASE_FIB;
        }
        else
        {
            fibFound = fibFinder(startingNumber - LAST) +
                    fibFinder(startingNumber - BEFORE_LAST);
        }
        return fibFound;
    }
}
