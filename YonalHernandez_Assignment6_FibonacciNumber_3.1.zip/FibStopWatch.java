/*=======================================================================
|     Source code: FibStopWatch.java
|           Class: FibStopWatch
|          Author: Yonal Hernandez
|      Student ID: 6178656
|      Assignment: Program #6 Recursive Fibonacci
|
|          Course: COP3337 Computer Programming II
|         Section: U02
|      Instructor: William Feild
|        Due Date: April 18, 2019 at the beginning of class
|
|	I hereby certify that this collective work is my own
|	and none of it is the work of any other person or entity.
|	_______Yonal Hernandez__________________________________
|
|        Language: Java
|     Compile/Run: Compile
| 	         javac FibStopWatch.java
|
|         Purpose: This class constructs a stopwatch that is in the stopped state
|   and has no time accumulated. It is used to measure the amount of time every
|   fibonacci sequence needs to find all the required numbers. Compute elapsedTime
|   in nanoseconds, and provides two methods to display time in seconds and
|   nanoseconds. Class uses worked example in Big Java: Early Objects, 5th Edition
|   page 634. Use method nanoTime() from the System class, returns the current
|   value of the running Java Virtual Machine's high-resolution time source, in
|   nanoseconds. For more information please refer to:
|  https://docs.oracle.com/javase/7/docs/api/java/lang/System.html#nanoTime()
|
|                               ****IMPORTANT****
|   Method nanoTime() can only be used to measure elapsed time and is not related to
|   any other notion of system or wall-clock time. The value returned represents
|   nanoseconds since some fixed but arbitrary origin time (perhaps in the future,
|   so values may be negative). The same origin is used by all invocations of this
|   method in an instance of a Java virtual machine; other virtual machine instances
|   are likely to use a different origin. This method provides nanosecond precision,
|   but not necessarily nanosecond resolution (that is, how frequently the value
|   changes) - no guarantees are made except that the resolution is at least as good
|   as that of currentTimeMillis(). Differences in successive calls that span greater
|   than approximately 292 years (263 nanoseconds) will not correctly compute elapsed
|   time due to numerical overflow. The values returned by this method become
|   meaningful only when the difference between two such values, obtained within the
|   same instance of a Java virtual machine, is computed.
|
|   Inherits From: None
|
|      Interfaces: None
|
|  +-----------------------------------------------------------------------
|
|       Constants:
|   private final double NANO_TO_SECONDS = 1000000000.0;
|       Used to convert time from nanoseconds to seconds.
|   private final int INITIAL_TIME = 0;
|       Used as reference to initialize variables to 0.
|
| +-----------------------------------------------------------------------
|
|    Constructors:
|   public FibStopWatch()
|       Default constructor for the class. Constructs a stopwatch that is in the
|       stopped state and has no time accumulated.
|
|   Class Methods:
|   private void reset()
|       Reset all variables to its initial state.
|
|Instance Methods:
|   public void start()
|
|   public void stop()
|
|   public long getElapsedTimeInNanoseconds()
|       return elapsedTime;
|   public double getElapsedTimeInSeconds()
|       return timeInSeconds
|
|  *===========================================================================*/


public class FibStopWatch
{
    private final double NANO_TO_SECONDS = 1000000000.0;
    private final int INITIAL_TIME = 0;

    private long elapsedTime = INITIAL_TIME;
    private long startTime = INITIAL_TIME;
    private long endTime = INITIAL_TIME;
    private boolean isRunning = false;

    /*---------------------- FibStopWatch ----------------------------
         |  Method FibStopWatch()
         |
         |Purpose: Default constructor for the class. Constructs a stopwatch that
         |  is in the stopped state and has no time accumulated by using reset()
         |  to set all variables to their initial state,
         |
         |  @param None
         |
         | @return None
         *-------------------------------------------------------------------*/
    public FibStopWatch()
    {
        reset();
    }

    /*------------------------------ reset -----------------------------------
         |  Method reset()
         |
         |Purpose: Private method to be used by the methods of the class. Set
         |  variables to their initial state.
         |
         |  @param None
         |
         | @return None
         *-------------------------------------------------------------------*/
    private void reset()
    {
        startTime = INITIAL_TIME;
        elapsedTime = INITIAL_TIME;
        isRunning = false;
    }

    /*----------------------------- start ------------------------------------
         |  Method start()
         |
         |Purpose: Start the stop watch if this is not running already. Use
         |  method nanoTime() from the System class, returns the current value
         |  of the running Java Virtual Machine's high-resolution time source,
         |  in nanoseconds. For more information please refer to:
         |  https://docs.oracle.com/javase/7/docs/api/java/lang/System.html#nanoTime()
         |
         |  @param None
         |
         | @return None
         *-------------------------------------------------------------------*/
    public void start()
    {
        if(!isRunning)
        {
            reset();
            isRunning = true;
            startTime = System.nanoTime();
        }
    }

    /*----------------------------- stop ------------------------------------
         |  Method stop()
         |
         |Purpose: Stop the stop watch if this is running, capture the time and
         |  compute the difference from end to start storing result in elapsedTime
         |  variable.
         |  Use method nanoTime() from the System class, returns the current value
         |  of the running Java Virtual Machine's high-resolution time source,
         |  in nanoseconds. For more information please refer to:
         |  https://docs.oracle.com/javase/7/docs/api/java/lang/System.html#nanoTime()
         |
         |  @param None
         |
         | @return None
         *-------------------------------------------------------------------*/
    public void stop()
    {
        if(isRunning)
        {
            isRunning = false;
            endTime = System.nanoTime();
            elapsedTime = endTime - startTime;
        }
    }

    /*------------------------- getElapsedTimeInNanoseconds---------------------
         |  Method getElapsedTimeInNanoseconds()
         |
         |Purpose: Returns elapsedTime in nanoseconds using a variable type long
         |  to avoid Arithmetic overflow. If the method is called and the time
         |  is running it stop the stopwatch first.
         |
         |  @param None
         |
         | @return elapsedTime
         *-------------------------------------------------------------------*/
    public long getElapsedTimeInNanoseconds()
    {
        if(isRunning)
        {
            stop();
        }
        return elapsedTime;
    }

    /*------------------------- getElapsedTimeInSeconds---------------------
         |  Method getElapsedTimeInSeconds()
         |
         |Purpose: Returns elapsedTime in seconds using a variable type double
         |  to then display the value with 4 decimal places accuracy. Divides
         |  time in nanoseconds by 10^9 to do the conversion. Throws
         |  ArithmeticException to prevent division by zero in case value of
         |  NANO_TO_SECONDS is changed by mistake.
         |
         |  @param None
         |
         | @return timeInSeconds
         *-------------------------------------------------------------------*/
    public double getElapsedTimeInSeconds() throws ArithmeticException
    {
        double timeInSeconds = getElapsedTimeInNanoseconds() / NANO_TO_SECONDS;
        return timeInSeconds;
    }
}
