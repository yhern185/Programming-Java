/*=======================================================================
|     Source code: UserInvalidValueException.java
|           Class: UserInvalidValueException
|          Author: Yonal Hernandez
|      Student ID: 6178656
|      Assignment: Program #6 Recursive Fibonacci
|
|          Course: COP3337 Computer Programming II
|         Section: U02
|      Instructor: William Feild
|        Due Date: April 18, 2019 at the beginning of class
|
|	I hereby certify that this collective work is my own
|	and none of it is the work of any other person or entity.
|	_______Yonal Hernandez__________________________________
|
|        Language: Java
|     Compile/Run: Compile
| 	         javac UserInvalidValueException.java
|
|         Purpose: This class reports bad input data by accepting a String
|   and displaying as a message using methods from it superclass.
|
|   Inherits From: java.io.IOException
|
|      Interfaces: None
|
|  +-----------------------------------------------------------------------
|
|       Constants: None
|
| +-----------------------------------------------------------------------
|
|    Constructors:
|   public UserInvalidValueException()
|       Default constructor for the class.
|
|   public UserInvalidValueException(String message)
|       Constructor that accepts a String as a message to be displayed using
|       it superclass methods.
|
|   Class Methods:  None
|
|Instance Methods:  None
|
|  *===========================================================================*/

public class UserInvalidValueException extends java.io.IOException
{
    /*---------------------- UserInvalidValueException ----------------------------
         |  Method UserInvalidValueException()
         |
         |Purpose: Default constructor for the class.
         |
         |  @param None
         |
         | @return None
         *-------------------------------------------------------------------*/
    public UserInvalidValueException()
    {

    }

    /*---------------------- UserInvalidValueException ----------------------------
         |  Method UserInvalidValueException(String message)
         |
         |Purpose: Constructor that accepts a String as a message to be displayed using
         |  it superclass methods.
         |
         |  @param None
         |
         | @return None
         *-------------------------------------------------------------------*/
    public UserInvalidValueException(String message)
    {
        super(message);
    }
}
